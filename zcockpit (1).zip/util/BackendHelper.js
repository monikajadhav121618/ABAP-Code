/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define([], function () {
    "use strict";

    var MAPPING = {
        "I": {
            "urlPath": "/ObjItemSet",
            "target": "ObjectsDetail"
        },
        "L": {
            "urlPath": "/LotSet",
            "target": "LotsDetail"
        },
        "C": {
            "urlPath": "/ContainerSet",
            "target": "ContainersDetail"
        },
        "T": {
            "urlPath": "/TransactionSet",
            "target": "TransactionsMaster"
        }
    };

    return {
        getInferredRoute: function (sCode) {
            return new Promise(function (resolve, reject) {
                var oComponent = sap.ui.getCore().getOwnerComponent();
                var oModel = oComponent.getModel();
                var sTarget = "";
                var that = this;
                var fnSuccess = function (oData, oResult) {
                    if (oData && oData.hasOwnProperty("ObjectType")) {
                        var bValid = oData.ObjectType in MAPPING;
                        if (bValid) {
                            var sTarget = MAPPING[oData.ObjectType].target;
                            var oRouteParam = oData.ObjectType === "T" ? { query: { query: encodeURIComponent(sCode) } } : { id: sCode };
                            resolve({
                                code: sCode,
                                type: oData.ObjectType,
                                route: sTarget,
                                routeParam: oRouteParam
                            });
                        } else {
                            reject();
                        }
                    };
                };
                oModel.read("/ObjTypeSet('" + encodeURIComponent(sCode) + "')", {
                    "success": fnSuccess,
                    "error": reject
                });
            });
        },

        getInferredObject: function (sCode, sExpand) {
            return new Promise(function (resolve, reject) {
                var oComponent = sap.ui.getCore().getOwnerComponent();
                var oModel = oComponent.getModel();
                var sUrlPath = "";
                var that = this;
                var fnSuccess = function (oData, oResult) {
                    if (oData && oData.hasOwnProperty("ObjectType")) {
                        var bValid = oData.ObjectType in MAPPING;
                        if (bValid) {
                            var sUrlPath = MAPPING[oData.ObjectType].urlPath;
                            var sUrl = sUrlPath + "('" + encodeURIComponent(sCode) + "')";
                            oModel.read(sUrl, {
                                "urlParameters": {
                                    "$expand": sExpand || ""
                                },
                                "success": function (oResult) {
                                    resolve({
                                        code: sCode,
                                        data: oResult,
                                        path: sUrl,
                                        type: oData.ObjectType
                                    });
                                },
                                "error": reject
                            });
                        } else {
                            reject();
                        }
                    };
                }
                oModel.read("/ObjTypeSet('" + encodeURIComponent(sCode) + "')", {
                    "success": fnSuccess
                });
            });
        }
    }
}, true);