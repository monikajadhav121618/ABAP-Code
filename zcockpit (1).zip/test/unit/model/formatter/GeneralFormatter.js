/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.require(
    [
        "com/sap/cd/sttp/zcockpit/model/formatter/GeneralFormatter"
    ],
    function(formatter) {
        "use strict";

        QUnit.module("General Formatter");

        function assertExpectStrictEqual(assert, sFn, aArguments, anyExpect) {
            var anyOutcome = formatter[sFn].apply(this, aArguments);
            assert.strictEqual(anyOutcome, anyExpect,
                "The formatter " +sFn + " worked correct for input: " + aArguments);
        }

        QUnit.test("Should remove leading zeros", function(assert) {
            assertExpectStrictEqual.call(this, assert, "RemoveLeadingZeros", ["000003"], "3");
            assertExpectStrictEqual.call(this, assert, "RemoveLeadingZeros", ["00000300030"], "300030");
            assertExpectStrictEqual.call(this, assert, "RemoveLeadingZeros", ["0000"], "0000");
            assertExpectStrictEqual.call(this, assert, "RemoveLeadingZeros", ["01010101010101010"], "1010101010101010");
            assertExpectStrictEqual.call(this, assert, "RemoveLeadingZeros", ["000AA15"], "000AA15");
        });

         QUnit.test("Should format Document position", function(assert) {
            assertExpectStrictEqual.call(this, assert, "DocPositionFormatter", ["0003", "1234"], "1234-0003");
            assertExpectStrictEqual.call(this, assert, "DocPositionFormatter", ["1", "0001"], "0001-1");
            assertExpectStrictEqual.call(this, assert, "DocPositionFormatter", ["0000", "0001"], "0001-0000");
        });

         QUnit.test("Should format Document position", function(assert) {
            assertExpectStrictEqual.call(this, assert, "DocPositionFormatter", ["0003", "1234"], "1234-0003");
            assertExpectStrictEqual.call(this, assert, "DocPositionFormatter", ["1", "0001"], "0001-1");
            assertExpectStrictEqual.call(this, assert, "DocPositionFormatter", ["0000", "0001"], "0001-0000");
        });
    }
);