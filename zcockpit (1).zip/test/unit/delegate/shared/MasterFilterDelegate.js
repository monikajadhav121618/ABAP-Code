/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.require(
    [
        "com/sap/cd/sttp/zcockpit/delegate/shared/MasterFilterDelegate",
        "sap/ui/table/Table",
        "sap/ui/comp/filterbar/FilterItem",
        "sap/m/Input",
        "sap/ui/model/odata/v2/ODataModel"
    ],
    function(delegate, Table, FilterItem, Input, ODataModel) {
        "use strict";

        QUnit.module("MasterFilter Delegate");
        
        QUnit.test("Should invoke search with empty criteria", function(assert) {
            var oTable = new Table({ threshold: 10 }),
                oModel = new ODataModel("/sap/opu/odata/sttp/ATT_COCKPIT_210_SRV/");
            oTable.setModel(oModel);

            var oEvent = {
                getSource : function() {
                    return {
                        getPersistencyKey : function() {
                            return "qunit-test-key";
                        },
                        data : function() {
                            return "ObjItemSet";
                        }
                    }
                },
                getParameter: function() {
                    return [                        
                        new Input({
                            name: "Gtin",
                            value: "123456789"
                        })
                    ]
                }
            };
            var oController = {
                byId : function() {
                    return oTable;
                }
            };

            delegate.onSearch.call(oController, oEvent);
            assert.ok(oTable.getBinding("rows"), "Table has binding.");
            assert.ok(oTable.getBinding("rows").aFilters.length > 0, "Table has at least one filter set.");
            assert.strictEqual(oTable.getBinding("rows").sFilterParams, "test", "Table has correct filter string.");
        });        
    }
);