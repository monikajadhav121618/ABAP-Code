/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.require(
    [
        "sap/ui/thirdparty/sinon",
        "sap/ui/thirdparty/sinon-qunit"
    ],
    function () {
        "use strict";

        QUnit.module("Component", {
            setup: function () {},
            teardown: function () {}
        });

        QUnit.test("Instantiation/Destroyal", function (assert) {
            var oComp = sap.ui.component({ name: "com.sap.cd.sttp.zcockpit" }),
                oConfig = oComp.getMetadata().getConfig(),
                expConfig = {
                    fullWidth : true,
                    i18nBundle : "com.sap.cd.sttp.zcockpit.i18n.messageBundle",
                    serviceUrl : "/sap/opu/odata/sttp/ATT_COCKPIT_210_SRV/"
                };

            // Asserts
            assert.ok(oComp, "Component initialized");
            assert.ok(oConfig, "Metadata/Config loaded");
            
            // Config comparison
            for ( var p in oConfig ) {
                if (oConfig.hasOwnProperty(p)) {
                    assert.strictEqual(oConfig[p], expConfig[p], "Config at " + p + " ok.");
                }
            }

            // Owner Component needed at some places
            assert.strictEqual(oComp, sap.ui.getCore().getOwnerComponent(), "Owner component bound to core.");

            // Check destroyed
            oComp.destroy();
            assert.ok(sap.ui.component({ name: "com.sap.cd.sttp.zcockpit" }), "Component destroyed and recreated");
        });
    }
);