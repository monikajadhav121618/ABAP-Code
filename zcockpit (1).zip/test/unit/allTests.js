/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define([
    "test/unit/Component",
    "test/unit/model/models",
    "test/unit/model/formatter/GeneralFormatter",
    "test/unit/delegate/shared/MasterFilterDelegate"
], function() { "use strict"; });