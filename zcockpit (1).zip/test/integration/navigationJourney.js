/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
/*global QUnit*/
/*global opaTest*/
 
sap.ui.require([
	"sap/ui/test/opaQunit"
], function () {
	"use strict";
 
	QUnit.module("Navigation");
 
	opaTest("Should open the hello dialog", function (Given, When, Then) {
 
		// Arrangements
		Given.iStartMyAppInAFrame(jQuery.sap.getResourcePath("com/sap/cd/sttp/zcockpit/test/FLPSandbox", ".html"));
 
		//Actions
		When.onTheAppPage.iPressTheSayHelloWithDialogButton();
 
		// Assertions
		Then.onTheAppPage.iShouldSeeTheHelloDialog().
			and.iTeardownMyAppFrame();
	});
});