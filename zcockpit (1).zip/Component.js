/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"com/sap/cd/sttp/zcockpit/model/models",
	"com/sap/cd/sttp/zcockpit/delegate/shared/CrossNavigationDelegate",
	//"com/sap/cd/sttp/zcockpit/localService/mockserver",
	"com/sap/cd/sttp/zcockpit/lib/epcismessageprovider/EPCISConfigProvider",
	"com/sap/cd/sttp/zcockpit/model/formatter/GeneralFormatter",
	"com/sap/cd/sttp/zcockpit/model/formatter/FixedValueFormatter",
	"com/sap/cd/sttp/zcockpit/model/formatter/FixedValueFormatterMD",
	"com/sap/cd/sttp/zcockpit/model/formatter/ExtensionFormatter",
	"com/sap/cd/sttp/zcockpit/delegate/shared/ExportDelegate",
	"com/sap/cd/sttp/zcockpit/delegate/shared/MasterFilterDelegate",
	"com/sap/cd/sttp/zcockpit/delegate/shared/MessageFileDelegate",
	"com/sap/cd/sttp/zcockpit/delegate/shared/DetailsDelegate",
	"com/sap/cd/sttp/zcockpit/delegate/shared/epcis/EPCISDelegate",
	"com/sap/cd/sttp/zcockpit/delegate/shared/epcis/DialogDelegate"
], function (UIComponent, Device, models, CrossNavigationDelegate, EPCISConfigProvider /*MockServer*/ ) {
	"use strict";

	return UIComponent.extend("com.sap.cd.sttp.zcockpit.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * In this function, the resource and application models are set and the router is initialized.
		 * @public
		 * @override
		 */
		init: function () {
			// convenience method to get OwnerComponent from everywhere
			var that = this;
			sap.ui.getCore().getOwnerComponent = function () {
				return that;
			};

			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// MockServer
			//MockServer.init();

			var oModel = this.getModel(); //models.createMainModel(mConfig);

			// register MessageManager on OdataModel
			var oMessageManager = sap.ui.getCore().getMessageManager();
			oMessageManager.registerMessageProcessor(oModel);
			this.setModel(oMessageManager.getMessageModel(), "messages");

			// set settings model
			this.setModel(models.createSettingsModel(this.getModel()), "settings");
			// set epcis config model
			EPCISConfigProvider.getConfigModel().then(function (oModel) {
				that.setModel(oModel, "config");
			});
			// set routing model for router
			this.setModel(models.createRoutingModel(this.getRouter()), "routing");
			// fetch FixedValues, set fixedValueSetModel and fill baseModel
			this.setModel(models.createFixedValuesModel(this.getModel()), "fixedValues");
			// fetch FixedValues, set fixedValueSetModel and fill md model
			this.setModel(models.createFixedValuesModel_MD(this.getModel("md")), "fixedValuesMD")
			// set extension model
			this.setModel(models.createExtensionModel(), "ext");


			//INFO: deactivated error handler because it's not compatible with version 1.28
			// initialize the error handler with the component
			//this._oErrorHandler = new ErrorHandler(this);

			// create the views based on the url/hash
			this.getRouter().initialize();
		},

		/**
		 * The component is destroyed by UI5 automatically.
		 * In this method, the ErrorHandler are destroyed.
		 * @public
		 * @override
		 */
		destroy: function () {
			// call the base component's destroy function
			UIComponent.prototype.destroy.apply(this, arguments);
		}
	});
});