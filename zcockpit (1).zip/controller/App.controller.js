/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define([
	"com/sap/cd/sttp/zcockpit/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"com/sap/cd/sttp/zcockpit/delegate/shared/outerPage/FooterDelegate"
], function (BaseController, JSONModel, FooterDelegate) {
	"use strict";

	return BaseController.extend("com.sap.cd.sttp.zcockpit.controller.App", {

		onInit: function () {
			if (this.onAppLoad) { // check whether any extension has implemented the hook...
				var oResourceModel = this.getOwnerComponent().getModel("i18n"); // get ResourceModel
				this.onAppLoad(oResourceModel); // ...and call it
			}
		},

		/**
		 * This lifecycle method is used to initialize the Shell Menu via its designated service. After some
		 * experiments only this place has been proven to do the job. If you do the initializiation before rendering
		 * the menu was not rendered when accessing the application via deep links.
		 * @public
		 */
		onAfterRendering: function () {
			var that = this;
			this.getOwnerComponent().getService("ShellUIService").then(function (oService) {
				var oShellHash = sap.ushell.Container.getService("URLParsing").getShellHash(window.location);
				oService.setHierarchy([{
						title: that.getModel("i18n").getProperty("SHELL_NAV_TRADE_ITMS"),
						icon: "sap-icon://pharmacy",
						intent: "#" + oShellHash + "&/tradeitems"
					},
					{
						title: that.getModel("i18n").getProperty("SHELL_NAV_SER_TRADE_ITMS"),
						icon: "sap-icon://bar-code",
						intent: "#" + oShellHash + "&/"
					},
					{
						title: that.getModel("i18n").getProperty("SHELL_NAV_LOTS"),
						icon: "sap-icon://lab",
						intent: "#" + oShellHash + "&/lots"
					},
					{
						title: that.getModel("i18n").getProperty("SHELL_NAV_SSCC"),
						icon: "sap-icon://product",
						intent: "#" + oShellHash + "&/containers"
					},
					{
						title: that.getModel("i18n").getProperty("SHELL_NAV_EVENTS"),
						icon: "sap-icon://alert",
						intent: "#" + oShellHash + "&/events"
					},
					{
						title: that.getModel("i18n").getProperty("SHELL_NAV_REPEVENTS"),
						icon: "sap-icon://marketing-campaign",
						intent: "#" + oShellHash + "&/repevents"
					},
					{
						title: that.getModel("i18n").getProperty("SHELL_NAV_TRANSACTIONS"),
						icon: "sap-icon://documents",
						intent: "#" + oShellHash + "&/transactions"
					},
					{
						title: that.getModel("i18n").getProperty("SHELL_NAV_AUTHREQUESTS"),
						icon: "sap-icon://complete",
						intent: "#" + oShellHash + "&/authrequests"
					},
					{
						title: that.getModel("i18n").getProperty("GLOBAL_SEARCH_TITLE"),
						icon: "sap-icon://search",
						intent: ""
					},
					{
						title: that.getModel("i18n").getProperty("HISTORY_TITLE"),
						icon: "sap-icon://history",
						intent: ""
					}
				]);

				sap.ui.getCore().byId("sapUshellNavHierarchyItems").getItems()[8].attachPress(FooterDelegate.handleFooterSearchPressed.bind(that));
				sap.ui.getCore().byId("sapUshellNavHierarchyItems").getItems()[9].attachPress(FooterDelegate.handleFooterHistoryPressed.bind(that));
			}).catch(function (oError) {
				jQuery.sap.log.error("Cannot get ShellUIService", oError, "com.sap.cd.sttp.zcockpit.Component");
			});
		}
	});

});