/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
/*global location*/
sap.ui.define([
	"com/sap/cd/sttp/zcockpit/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"com/sap/cd/sttp/zcockpit/delegate/shared/PersonalizationDelegate",
	"com/sap/cd/sttp/zcockpit/delegate/shared/DetailsDelegate",
	"com/sap/cd/sttp/zcockpit/delegate/shared/epcis/EPCISDelegate"
], function(
	BaseController,
	JSONModel,
	MessageBox,
	PersonalizationDelegate,
	DetailsDelegate,
	EPCISDelegate
) {
	"use strict";

	return BaseController.extend("com.sap.cd.sttp.zcockpit.controller.objects.Detail", {

		/**
		 * Called when the object/Detail controller is instantiated. Registers the route handler and on a matched route
		 * one single trade item is retrieved from the backend with the required navigation properties. Some tabs
		 * of the Details screen require additional requests to the backend for loading additional sets of entities.
		 * These sets have different implementations. Some have to be filtered, others like the hierarchy need to be
		 * determined by a root node. Therefore always the 'currentObjectId' and the 'lastObjId' are held as controller-scoped
		 * local variables. If the overall context binding changes these additional entities need to be reloaded.
		 * @public
		 */
		onInit: function() {
			PersonalizationDelegate.initTablePersonalizationForTable("objectsDetailHierarchy", this.getView().byId("treeTable"));
			PersonalizationDelegate.initTablePersonalizationForTable("objectsDetailAuthReq", this.getView().byId("authRequestsTable"));
				
			var that = this;
			this.getOwnerComponent().getRouter().attachRoutePatternMatched(function(oEvent) {
				if (oEvent.getParameter("name") === "ObjectsDetail") {

					var sUrl = "/ObjItemSet('" + encodeURIComponent(oEvent.getParameter("arguments").id) + "')";

					that.sCurrentId = "";
					that.getOwnerComponent().aHierarchyPath = [];

					that.getView().setBusy(true);

					that.getView().getModel().read(sUrl, {						
						"success": $.proxy(function(oData) {

							if (!oData.Objid) {
								that.getOwnerComponent().getRouter().navTo("NotFound", {}, true);
								return;
							}

							that.getView().bindObject(sUrl, {
								expand: "Evt,RepEvt,Trn,Lot,Attrib"
							});

							that.sCurrentId = oData.Objid;
							
							DetailsDelegate.locateObject.bind(that)();
							EPCISDelegate.checkAuthenticationForEPCISActions.bind(that)(oData.Gln);

							if (that.sCurrentId !== that.sLastId) {
								that.getView().needsToLoadHierarchy = true;
								that.getView().needsToLoadAuthRequests = true;
							}

							that.sLastId = that.sCurrentId;

							that.getView().setBusy(false);

							if (that.getView().byId("iconTabBar").getSelectedKey() === "hierarchy") {
								that.loadHierarchy();
							}

							if (that.getView().byId("iconTabBar").getSelectedKey() === "authRequests") {
								that.loadAuthRequests();
							}

						}, this),
						"error": $.proxy(function() {
							that.getOwnerComponent().getRouter().navTo("NotFound", {}, true);
						}, this)
					});
				}
			});
		},

		/**
		 * Checks whether the hierarchy for the 'currentObjectId' needs to be loaded (This is the case if it is the first
		 * instantiation of the controller or if the 'currentObjectId' has changed). Depending on the result the new data
		 * is retrieved from the backend and binded to the correct table. The backend implementation of the hierarchy is very
		 * different from standard OData Entities. Only modify with utter care.
		 * @public
		 */
		loadHierarchy: function() {
			if (this.getView().needsToLoadHierarchy) {
				this.getView().needsToLoadHierarchy = false;
				this.getView().byId("treeTable").bindRows({
					path: '/HierarchyNodeSet',
					parameters: {
						numberOfExpandedLevels: 1,
						countMode: 'Inline'
					},
					filters: new sap.ui.model.Filter("InitialNodeId", sap.ui.model.FilterOperator.EQ, this.sCurrentId)
				});
			}

		},

		/**
		 * Checks whether the authentication requests for the 'currentObjectId' need to be loaded (This is the case if it
		 * is the first instantiation of the controller or if the 'currentObjectId' has changed). Depending on the result
		 * the new data is retrieved from the backend and binded to the correct table.
		 * @public
		 */
		loadAuthRequests: function() {
			if (this.getView().needsToLoadAuthRequests) {
				this.getView().needsToLoadAuthRequests = false;
				var oFilter = new sap.ui.model.Filter("ItmObjid", sap.ui.model.FilterOperator.EQ, this.sCurrentId);
				this.getView().byId("authRequestsTable").bindRows({
					path: "/AuthRequestSet",
					parameters : { expand : "Attrib"},
					filters: oFilter
				});
			}
		},

		/**
		 * This hook is called after an IconTabBar Tab has been selected that is not part of the standard application.
		 * Use handler onTabChanged in your own controller to implement custom logic for your custom Tabs.
		 * sTabKey can be used to identify the selected Tab.
		 * @public
		 */
		extHook_onTabChanged: function(sTabKey) {
			if (this.onTabChanged) {         			// check whether any extension has implemented the hook...
				this.onTabChanged(sTabKey); 			// ...and call it
			}
		}
	});
});