/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define([
    "com/sap/cd/sttp/zcockpit/controller/BaseController",
    "sap/m/MessageBox",
    "sap/ui/model/json/JSONModel",
    "com/sap/cd/sttp/zcockpit/delegate/shared/PersonalizationDelegate",
    "com/sap/cd/sttp/zcockpit/util/BackendHelper",
    "sap/ui/thirdparty/d3"
], function (BaseController, MessageBox, JSONModel, PersonalizationDelegate, BackendHelper) {

    return BaseController.extend("com.sap.cd.sttp.zcockpit.controller.histhierarchy.Hierarchy", {
        sEpcId: "",
        sCurrentGs1: "",
        sTimestamp: "",
        bIsD3: false,

        /**
        * Called when the HistoricHierarchy controller is instantiated. Registers the route handler and on a matched route
        * one single transaction is retrieved from the backend with the required navigation properties. sEpcId and sTimestamp
        * reflect the currently shown Object and Event in the View. Initially always table mode is active. If no Object is yet
        * loaded the Routematched Handler requests the ItemData which then requests the HierarchyData.
        * @public
        */
        onInit: function () {
            PersonalizationDelegate.initTablePersonalizationForTable("histHierarchyTable", this.getView().byId("treeTable"), null, null, 50);
            var that = this;
            this.setModel(new JSONModel({}), "vm");
            this.getOwnerComponent().getRouter().attachRoutePatternMatched(function (oEvent) {
                if (oEvent.getParameter("name") === "HistHierarchy") {
                    var split = oEvent.getParameter("arguments").id.split(",");

                    var sEpcId = split[0];
                    var sTimestamp = split[1].trim();

                    if (!that.sEpcId || that.sEpcId !== sEpcId || (that.sEpcId === sEpcId && that.sTimestamp !== sTimestamp)) {
                        that.switchToTable();
                        that.sEpcId = sEpcId;
                        that.sTimestamp = sTimestamp;
                        that.aColors = [];
                        that._getItemData(sEpcId, that.sTimestamp);
                    }
                }
            });
        },

        /**
		 * Simply creates a promise to reflect if View is ready to be drawn on by d3.js
		 * @public
		 */
        onAfterRendering: function () {
            this.isReady = new Promise(function (resolve, reject) {                
                resolve();
            });
        },

        /**
		 * Toggles visibility of OjectPageLayout HeaderContent
		 * @public
		 */
        onCollapsePressed: function(oEvent) {
            var oHeader = this.getView().byId("eventDetailsForm");
            if ( oHeader.getShowHeaderContent() ) {
                oEvent.getSource().setText(this.getView().getModel("i18n").getProperty("EXPAND_DETAILS"));
                oHeader.setShowHeaderContent(false);
            } else {
                oEvent.getSource().setText(this.getView().getModel("i18n").getProperty("COLLAPSE_DETAILS"));
                oHeader.setShowHeaderContent(true);
            }
        },

        /**
		 * Removes all d3 artifacts from DOM
		 * @public
		 */
        clearD3: function() {
            var dom = this.getView().$();
            dom.find(".mainSvg").remove();
        },

        /**
		 * Event handler for user interaction with the custom DataSlider control. Initiates loading of a new hierarchy tree JSON file from backend.
		 * @public
		 */
        dataSliderChanged: function (oEvent) {
            var oItem = oEvent.getParameter("item");
            this.sTimestamp = oItem.getBindingContext().getObject().EvttimeExact.trim();
            var oHashChanger = sap.ui.core.routing.HashChanger.getInstance();
            var sHash = oHashChanger.getHash();
            var sHashWithoutTime = sHash.substring(0, sHash.lastIndexOf(","));
            oHashChanger.replaceHash(sHashWithoutTime + "," + this.sTimestamp);
            this.getView().byId("histHeader").bindObject(oItem.getBindingContext().getPath());
            this.getView().byId("eventDetailsForm").bindObject(oItem.getBindingContext().getPath());
            this.clearD3();
            this._loadHierarchy(this.sEpcId, this.sTimestamp);
        },

        /**
		 * Called when the togglebutton for the Table mode is pressed. Removes all d3 content and sets the table control to
         * visible.
		 * @public
		 */
        switchToTable: function (oEvent) {
            this.getView().byId("viewSwitchButtons").setSelectedButton(null);
            if (this.bIsD3) {
                this.bIsD3 = false;
                this.clearD3();
                this.getView().byId("treeTable").setVisible(true);
            }
        },

        /**
		 * Called when the togglebutton for the Visual mode is pressed. Sets the table to invisible and initiates d3
         * rendering of the hierarchy data.
		 * @public
		 */
        switchToD3: function (oEvent) {
            if (!this.bIsD3) {
                this.bIsD3 = true;
                this.getView().byId("treeTable").setVisible(false);
                this._doD3(this.sEpcId, this.sTimestamp);
            }
        },

        /**
		 * Always called when the hierarchy data changes. Highlights the current object and its path to the root in
         * the hierarchy table by recursive traversing through the Json Tree.
		 * @private
		 */
        _highlightCurrent: function (oJson) {
            var that = this;
            var sCode = that.sCurrentGs1;

            var highlight = function (oCurrent) {
                if (oCurrent.n === sCode) {
                    oCurrent.h = true;
                    return true;
                } else {
                    for (var i in oCurrent.children) {
                        if (highlight(oCurrent.children[i])) {
                            oCurrent.h = true;
                            return true;
                        }
                    }
                }
            }
            highlight(oJson);
        },

        /**
		 * Requests the object data from the backend. Hist. Hierarchy is available for both Containers(SSCC) and Ser.
         * Trade Items. Therefore both Backend services are called, regardless if one is failing.
		 * @private
		 */
        _getItemData: function (sEpcId, sTimestamp) {
            var that = this;
            var sExpand = "Evt";
            BackendHelper.getInferredObject(sEpcId, sExpand)
                .then(function (oResult) {                   
                    var oData = oResult.data;
                    if (oData && !oData.Objid) {
                        that.getOwnerComponent().getRouter().navTo("NotFound", {}, true);
                        return;
                    }
                    if (oData && oData.Objid) {
                        that.getView().bindObject(oResult.path, {
                            expand: sExpand
                        });
                        that.sCurrentGs1 = oData.Gs1EsB;
                        that.getView().setModel(new JSONModel(oData), "obj");
                        that._selectCurrentButton(sTimestamp);
                        that._loadHierarchy(sEpcId, sTimestamp);
                    }
                }).catch(function() {
                    that.getOwnerComponent().getRouter().navTo("NotFound", {}, true);
                });
        },

        /**
		 * Selects the current button which reflects the currently shown Event. This is required, because the page
         * could be opened by a direct link to a specific Event and specific URL.
		 * @private
		 */
        _selectCurrentButton: function (sTimestamp) {
            var oDataSlider = this.getView().byId("dataSlider");
            var aTickItems = oDataSlider.getItems();
            var iCurrentTickIndex = null;
            for (var i = 0, len = aTickItems.length; i < len; i++) {
                if (aTickItems[i].getBindingContext().getObject().EvttimeExact.trim() === sTimestamp) {
                    iCurrentTickIndex = i;
                    break;
                }
            }
            oDataSlider.setValue(iCurrentTickIndex);
            this.getView().byId("histHeader").bindObject(aTickItems[i].getBindingContext().getPath());            
            this.getView().byId("eventDetailsForm").bindObject(aTickItems[i].getBindingContext().getPath());
        },


        /**
		 * This function contains the d3.js rendering rules and some sub functions. It uses d3.layout.pack() as
         * a performant and feasible implementation to render the pack hierarchy of a serialized container.
		 * @private
		 */
        _doD3: function (sDataUrl) {
            var oD3Content = this.getView().byId("d3Content");
            var that = this;
            var w = $(oD3Content.getDomRef()).width(),
                h = $(oD3Content.getDomRef()).height(),
                r = $(oD3Content.getDomRef()).height() - 10,
                x = d3.scale.linear().range([0, r]),
                y = d3.scale.linear().range([0, r]),
                node,
                root;

            var pack = d3.layout.pack()
                .size([r, r])
                .value(function (d) { return 1; /*d.q;*/ });

            
            this.vis = d3.select("#" + oD3Content.getId()).append("svg:svg")
                .attr("class", "mainSvg")
                .attr("width", w)
                .attr("height", h)
                .append("svg:g")
                .attr("transform", "translate(" + (w - r) / 2 + "," + (h - r) / 2 + ")");
            this.ttdiv = d3.select("body").append("div")
                .attr("class", "tooltip")
                .style("opacity", 0);
            

            /**
             * This function detects if the border of parent items are overlayed. This is always the case if the
             * pack hierarchy contains paths where parent items have only one child. In these cases the user is not
             * able to hover on the outer item. Therefore the name/id tooltips are converged into one tooltip that
             * contains all overlaying information.
             * @private
             */
            function _getOverlaying(d) {
                var radius = d.r,
                    current1 = d,
                    current2 = d,
                    array = ["<b>" + d.n + "<b>"],
                    string;
                while (current1.parent && current1.parent.r === radius) {
                    array.splice(0, 0, current1.parent.n);
                    current1 = current1.parent;
                }

                while (current2.children && current2.children.length === 1 && current2.children[0].r === radius) {
                    array.push(current2.children[0].n);
                    current2 = current2.children[0];
                }

                for (var i = 1, len = array.length; i < len; i++) {
                    array[i] = "&#8627; " + array[i];
                }
                string = array.join("</br>");
                return string;
            }

            /**
             * This function adds different CSS classes to objects that have different GTIN origin. This is currently
             * limited to 6 different classes which reflect 6 different colors. It enables the end user to see if
             * containers are packed homogeneously or not.
             * @private
             */
            function _pickClass(d) {
                if (!d.children) {
                    var sIdx = d.n.indexOf("(01)");
                    if (sIdx >= 0) {
                        var sGtin = d.n.substring(sIdx, 18);
                        if (that.aColors.indexOf(sGtin) < 0) {
                            that.aColors.push(sGtin);
                        }
                        return "c" + that.aColors.indexOf(sGtin);
                    } else {
                        return "c" + "Transparent";
                    }
                }
            }

            that.vis.selectAll("circle").remove();
            node = root = jQuery.extend(true, {}, that.oJsonModel.getData().root || {}); // creates a deep copy
            var nodes = pack.nodes(root);

            that.vis.selectAll("circle")
                .data(nodes)
                .enter().append("svg:circle")
                .attr("class", function (d) { return d.children ? "p" : "c " + _pickClass(d); })
                .classed("h", function (d) { return d.n === that.sCurrentGs1; })
                .attr("cx", function (d) { return d.x; })
                .attr("cy", function (d) { return d.y; })
                .attr("r", function (d) { return d.r; })
                .on("click", function (d) { return zoom(node == d ? root : d); })
                .on('mouseover', function (d) {
                    that.ttdiv.transition()
                        .duration(200)
                        .style("opacity", .9);
                    that.ttdiv.html(_getOverlaying(d))
                        .style("left", (d3.event.pageX + 10) + "px")
                        .style("top", (d3.event.pageY - 28) + "px");
                })
                .on('mouseout', function (d) {
                    that.ttdiv.transition()
                        .duration(500)
                        .style("opacity", 0);
                });

            d3.select(window).on("click", function () { zoom(root); });

            oD3Content.setBusy(false);

            /**
             * Implementation of the zoom functionality which is executed when clicking on a circle.
             * @public
             */
            function zoom(d, i) {
                if (!that.vis) {
                    return;
                }
                var k = r / d.r / 2;
                x.domain([d.x - d.r, d.x + d.r]);
                y.domain([d.y - d.r, d.y + d.r]);

                var t = that.vis.transition()
                    .duration(d3.event.altKey ? 7500 : 750);

                t.selectAll("circle")
                    .attr("cx", function (d) { return x(d.x); })
                    .attr("cy", function (d) { return y(d.y); })
                    .attr("r", function (d) { return k * d.r; });

                node = d;
                d3.event.stopPropagation();
            }
        },


        /**
		 * Loads the JSON hierarchy from the backend for the given sEpcId and sTimestamp. If this request fails or
         * the response is an empty JSON, a warning popup is shown to the user.
		 * @private
		 */
        _loadHierarchy: function (sEpcId, sTimestamp) {
            this.getView().byId("d3Content").setBusy(true);
            this.getView().byId("d3Content").setBusyIndicatorDelay(0);
            var that = this;
            this.getView().getModel().read("/GetHierarchyJson", {
                urlParameters: {
                    "Objcode": "'" + sEpcId + "'",
                    "Timestamp": "'" + sTimestamp + "'"
                },
                success: function (oData) {
                    if (oData && oData.TextValue) {
                        that.isReady.then(function () {
                            if (!that.oJsonModel) {
                                that.oJsonModel = new JSONModel();
                                that.getView().byId("treeTable").setModel(that.oJsonModel, "hry");
                            }
                            $.getJSON(oData.TextValue)
                                .done(function (oJson) {
                                    that._highlightCurrent(oJson);
                                    that.oJsonModel.setData({ "root": oJson });
                                    that.getView().byId("treeTable").bindRows("hry>/");
                                    if (that.bIsD3) {
                                        that._doD3();
                                    } else {
                                        that.getView().byId("d3Content").setBusy(false);
                                    }
                                })
                                .fail(function () {
                                    MessageBox.show(that.getView().getModel("i18n").getProperty("HIST_HRY_NOT_AVAILABLE"), {
                                        icon: MessageBox.Icon.Warning,
                                        title: that.getView().getModel("i18n").getProperty("WARNING")
                                    });
                                    that.getView().byId("d3Content").setBusy(false);
                                    that.getView().byId("treeTable").unbindRows();
                                    that.clearD3();
                                })
                        });
                    }
                }
            });
        }
    });
});