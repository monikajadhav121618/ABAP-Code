/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define([
	"com/sap/cd/sttp/zcockpit/controller/BaseController",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
	"com/sap/cd/sttp/zcockpit/delegate/shared/PersonalizationDelegate",
	"com/sap/cd/sttp/zcockpit/delegate/shared/MasterFilterDelegate"
], function(BaseController, Export, ExportTypeCSV, PersonalizationDelegate, MasterFilterDelegate) {
	"use strict";

	return BaseController.extend("com.sap.cd.sttp.zcockpit.controller.lots.Master", {
		onInit: function() {
			PersonalizationDelegate.initTablePersonalizationForView("lotsMaster", this.getView());
			PersonalizationDelegate.initVariantManagementForView("lotsMaster", this.getView());
		},

		onAfterRendering: function(oEvent) {
			MasterFilterDelegate.registerKeyUp(oEvent);
		}
	});
});