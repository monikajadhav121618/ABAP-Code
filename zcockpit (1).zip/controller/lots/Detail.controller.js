/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
/*global location*/
sap.ui.define([
	"com/sap/cd/sttp/zcockpit/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"com/sap/cd/sttp/zcockpit/delegate/shared/PersonalizationDelegate"
], function(
	BaseController,
	JSONModel,
	MessageBox,
	PersonalizationDelegate
) {
	"use strict";

	return BaseController.extend("com.sap.cd.sttp.zcockpit.controller.lots.Detail", {
		sUrl: "",

		
		/**
		 * Called when the lot/Details controller is instantiated. Registers the route handler and on a matched route
		 * one single lot is retrieved from the backend with the required navigation properties. Some tabs
		 * of the Details screen require additional requests to the backend for loading additional sets of entities.
		 * Therefore always the 'currentLotObjId' and the 'lastLotObjId' are held as controller-scoped local
		 * variables. If the overall context binding changes these additional entities need to be reloaded.
		 * @public
		 */
		onInit: function() {
			PersonalizationDelegate.initTablePersonalizationForTable("lotsDetailRelatedObj", this.getView().byId("LotObjItmTable"));
			PersonalizationDelegate.initTablePersonalizationForTable("lotsDetailAuthReq", this.getView().byId("authRequestsTable"));
			
			var that = this;
			this.getOwnerComponent().getRouter().attachRoutePatternMatched(function(oEvent) {
				if (oEvent.getParameter("name") === "LotsDetail") {
					var sUrl = "/LotSet('" + encodeURIComponent(oEvent.getParameter("arguments").id) + "')";
					this.sUrl = sUrl;

					that.sCurrentId = "";
					that.getOwnerComponent().aHierarchyPath = [];

					that.getView().setBusy(true);

					that.getView().getModel().read(sUrl, {
						"success": $.proxy(function(oData) {

							if (!oData.Objid) {
								that.getOwnerComponent().getRouter().navTo("NotFound", {}, true);
								return;
							}

							that.getView().bindObject(sUrl, {
								expand: "Evt,RepEvt,Trn,Attrib"
							});

							that.sCurrentId = oData.Objid;

							if (that.sCurrentId !== that.sLastId) {
								that.getView().needsToLoadLotObjItms = true;
								that.getView().needsToLoadAuthRequests = true;
							}

							that.sLastId = that.sCurrentId;

							that.getView().setBusy(false);

							if (that.getView().byId("iconTabBar").getSelectedKey() === "relatedTradeItems") {
								that.loadLotObjItms();
							}

							if (that.getView().byId("iconTabBar").getSelectedKey() === "authRequests") {
								that.loadAuthRequests();
							}

						}, this),
						"error": $.proxy(function() {
							that.getOwnerComponent().getRouter().navTo("NotFound", {}, true);
						}, this)
					});
				}
			});
		},

		/**
		 * Checks whether the related trade items for the 'currentLotObjId' need to be loaded (This is the case if it
		 * is the first instantiation of the controller or if the 'currentLotObjId' has changed). Depending on the result
		 * the new data is retrieved from the backend and binded to the correct table.
		 * @public
		 */
		loadLotObjItms: function() {
			if (this.getView().needsToLoadLotObjItms) {
				this.getView().needsToLoadLotObjItms = false;
				var oFilter = new sap.ui.model.Filter("LotObjid", sap.ui.model.FilterOperator.EQ, this.sCurrentId);
				this.getView().byId("LotObjItmTable").bindRows({
					path: "/ObjItemSet",
					parameters : { expand : "Attrib"},
					filters: oFilter
				});
			}
		},

		/**
		 * Checks whether the authentication requests for the 'currentLotObjId' need to be loaded (This is the case if it
		 * is the first instantiation of the controller or if the 'currentLotObjId' has changed). Depending on the result
		 * the new data is retrieved from the backend and binded to the correct table.
		 * @public
		 */
		loadAuthRequests: function() {
			if (this.getView().needsToLoadAuthRequests) {
				this.getView().needsToLoadAuthRequests = false;
				var oFilter = new sap.ui.model.Filter("LotObjid", sap.ui.model.FilterOperator.EQ, this.sCurrentId);
				this.getView().byId("authRequestsTable").bindRows({
					path: "/AuthRequestSet",
					parameters : { expand : "Attrib"},
					filters: oFilter
				});
			}
		},

		/**
		 * This hook is called after an IconTabBar Tab has been selected that is not part of the standard application.
		 * Use handler onTabChanged in your own controller to implement custom logic for your custom Tabs.
		 * sTabKey can be used to identify the selected Tab.
		 * @public
		 */
		extHook_onTabChanged: function(sTabKey) {
			if (this.onTabChanged) {         			// check whether any extension has implemented the hook...
				this.onTabChanged(sTabKey); 			// ...and call it
			}
		}
	});
});