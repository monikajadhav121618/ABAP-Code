/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
/*global location*/
sap.ui.define([
	"com/sap/cd/sttp/zcockpit/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"com/sap/cd/sttp/zcockpit/delegate/shared/PersonalizationDelegate"
], function(
	BaseController,
	JSONModel,
	MessageBox,
	PersonalizationDelegate
) {
	"use strict";

	return BaseController.extend("com.sap.cd.sttp.zcockpit.controller.transactions.Detail", {
		sUrl: "",

		/**
		 * Called when the transactions/Detail controller is instantiated. Registers the route handler and on a matched route
		 * one single transaction is retrieved from the backend with the required navigation properties. Some tabs
		 * of the Details screen require additional requests to the backend for loading additional sets of entities. These sets
		 * have different implementations. Therefore always the 'currentTrnId' and the 'lastTrnId' are held as controller
		 * -scoped local variables. If the overall context binding changes these additional entities need to be reloaded.
		 * @public
		 */
		onInit: function() {	
			PersonalizationDelegate.initTablePersonalizationForTable("transactionsDetailObjects", this.getView().byId("GenObjTable"), null, true);	
			var that = this;
			this.getOwnerComponent().getRouter().attachRoutePatternMatched(function(oEvent) {
				if (oEvent.getParameter("name") === "TransactionsDetail") {
					
					var split = oEvent.getParameter("arguments").id.split(",");
					
					var sUrl = "/TransactionSet(Trncode='" + encodeURIComponent(split[0]) + "',Bizttype='" + encodeURIComponent(split[1]) +"')";
					this.sUrl = sUrl;

					that.sCurrentId = "";
					that.getOwnerComponent().aHierarchyPath = [];

					that.getView().setBusy(true);

					that.getView().getModel().read(sUrl, {
						"success": $.proxy(function(oData) {

							if (!oData.Trnid) {
								that.getOwnerComponent().getRouter().navTo("NotFound", {}, true);
								return;
							}

							that.getView().bindObject(sUrl, {
								expand: "Evt,TrnTrnItm,Attrib"
							});
							
							that.sCurrentId = oData.Trnid;


                            if (that.sCurrentId !== that.sLastId) {
							    that.getView().needsToLoadRelatedObjects = true;
							    that.getView().needsToLoadRelatedItemsComp = true;
                            }
                            
                            that.sLastId = that.sCurrentId;
							
							that.getView().setBusy(false);

							if (that.getView().byId("iconTabBar").getSelectedKey() === "relatedObjects") {
								that.loadRelatedObjects();
							}
							
							if (that.getView().byId("iconTabBar").getSelectedKey() === "relatedItemsCompare") {
								that.loadRelatedItemsComp();
							}
							
						}, this),
						"error": $.proxy(function() {
							that.getOwnerComponent().getRouter().navTo("NotFound", {}, true);
						}, this)
					});
				}
			});
		},


		/**
		 * Checks whether the related objects (lot,sscc,item) for the 'currentTrnId' need to be loaded (This is the case 
		 * if it is the first instantiation of the controller or if the 'currentTrnId' has changed). Depending on the result
		 * the new data is retrieved from the backend and binded to the correct table.
		 * @public
		 */
		loadRelatedObjects: function() {
		    if (this.getView().needsToLoadRelatedObjects) {
    			this.getView().needsToLoadRelatedObjects = false;
    			var oFilter = new sap.ui.model.Filter("Trnid", sap.ui.model.FilterOperator.EQ, this.sCurrentId);
    				this.getView().byId("GenObjTable").bindRows({
    					path: "/GenericObjectSet",
    					filters: oFilter
    				});
		    }
		},
		

		/**
		 * Checks whether the related transaction items for the 'currentTrnId' need to be loaded (This is the case 
		 * if it is the first instantiation of the controller or if the 'currentTrnId' has changed). Depending on the result
		 * the new data is retrieved from the backend and binded to the correct table.
		 * Note: This uses sap.m.Table instead of sap.ui.table.Table
		 * @public
		 */
		loadRelatedItemsComp: function() {
		    if (this.getView().needsToLoadRelatedItemsComp) {
    			this.getView().needsToLoadRelatedItemsComp = false;
    			var oFilter = new sap.ui.model.Filter("Trnid", sap.ui.model.FilterOperator.EQ, this.sCurrentId);
    				this.getView().byId("relatedItemsCompareTable").bindItems({
    					path: "/TrnItemCompSet",
    					filters: oFilter,
    					template: sap.ui.xmlfragment("com.sap.cd.sttp.zcockpit.fragment.transactions.detail.relatedItemsCompare.TableTemplate", this)
    				});
		    }
		},

		/**
		 * This hook is called after an IconTabBar Tab has been selected that is not part of the standard application.
		 * Use handler onTabChanged in your own controller to implement custom logic for your custom Tabs.
		 * sTabKey can be used to identify the selected Tab.
		 * @public
		 */
		extHook_onTabChanged: function(sTabKey) {
			if (this.onTabChanged) {         			// check whether any extension has implemented the hook...
				this.onTabChanged(sTabKey); 			// ...and call it
			}
		}
	});
});