/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define([
	"com/sap/cd/sttp/zcockpit/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"com/sap/cd/sttp/zcockpit/delegate/shared/PersonalizationDelegate",
	"com/sap/cd/sttp/zcockpit/delegate/shared/MasterFilterDelegate"
], function(BaseController, JSONModel, Filter, FilterOperator,
	PersonalizationDelegate, MasterFilterDelegate) {
	"use strict";

	return BaseController.extend("com.sap.cd.sttp.zcockpit.controller.transactions.Master", {
		aFilters: [],

		onInit: function() {
			PersonalizationDelegate.initTablePersonalizationForView("transactionsMaster", this.getView());
			PersonalizationDelegate.initVariantManagementForView("transactionsMaster", this.getView());

			var that = this; 
			this.getRouter().attachRoutePatternMatched(function(oEvent) {
				if (oEvent.getParameter("name") === "TransactionsMaster" && oEvent.getParameter("arguments")["?query"]) {
					that.getView().byId("inputTrnCode").setValue(decodeURIComponent(oEvent.getParameter("arguments")["?query"].query));
					that.getView().byId("filterbar").search();
				}
			});
		},

		onAfterRendering: function(oEvent) {
			MasterFilterDelegate.registerKeyUp(oEvent);
		}
	});
});