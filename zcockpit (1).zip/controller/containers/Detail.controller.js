/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
/*global location*/
sap.ui.define([
	"com/sap/cd/sttp/zcockpit/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"com/sap/cd/sttp/zcockpit/delegate/shared/PersonalizationDelegate",
	"com/sap/cd/sttp/zcockpit/delegate/shared/DetailsDelegate",
	"com/sap/cd/sttp/zcockpit/delegate/shared/epcis/EPCISDelegate",
	"com/sap/cd/sttp/zcockpit/delegate/shared/MapDelegate"
], function (
	BaseController,
	JSONModel,
	MessageBox,
	PersonalizationDelegate,
	DetailsDelegate,
	EPCISDelegate,
	MapDelegate
) {
		"use strict";

		return BaseController.extend("com.sap.cd.sttp.zcockpit.controller.containers.Detail", {

			/**
			 * Called when the containers/Details controller is instantiated. Registers the route handler and on a matched route
			 * one single container is retrieved from the backend with the required navigation properties. Some tabs
			 * of the Details screen require additional requests to the backend for loading additional sets of entities.
			 * These sets have different implementations. Some have to be filtered, others like the hierarchy need to be
			 * determined by a root node. Therefore always the 'currentObjectId' and the 'lastObjId' are held as controller-scoped
			 * local variables. If the overall context binding changes these additional entities need to be reloaded.
			 * @public
			 */
			onInit: function () {
				PersonalizationDelegate.initTablePersonalizationForTable("containersDetailHierarchy", this.getView().byId("treeTable"));
				//MapDelegate.initMap.bind(this)();

				var that = this;
				this.getOwnerComponent().getRouter().attachRoutePatternMatched(function (oEvent) {
					if (oEvent.getParameter("name") === "ContainersDetail") {

						var sUrl = "/ContainerSet('" + encodeURIComponent(oEvent.getParameter("arguments").id) + "')";

						that.sCurrentId = "";
						that.getOwnerComponent().aHierarchyPath = [];

						that.getView().setBusy(true);

						that.getView().getModel().read(sUrl, {
							"success": $.proxy(function (oData) {

								if (!oData.Objid) {
									that.getOwnerComponent().getRouter().navTo("NotFound", {}, true);
									return;
								}

								that.getView().bindObject(sUrl, {
									expand: "Evt,RepEvt,Trn,Attrib"
								});

								that.sCurrentId = oData.Objid;

								DetailsDelegate.locateObject.bind(that)();
								EPCISDelegate.checkAuthenticationForEPCISActions.bind(that)(oData.Gln);

								if (that.sCurrentId !== that.sLastId) {
									that.getView().needsToLoadHierarchy = true;
									that.getView().needsToLoadEventLocationData = true;
								}

								that.sLastId = that.sCurrentId;

								that.getView().setBusy(false);

								if (that.getView().byId("iconTabBar").getSelectedKey() === "hierarchy") {
									that.loadHierarchy();
								}

								if (that.getView().byId("iconTabBar").getSelectedKey() === "eventsMap") {
									that.loadEventLocationData();
								}

							}, this),
							"error": $.proxy(function () {
								that.getOwnerComponent().getRouter().navTo("NotFound", {}, true);
							}, this)
						});
					}
				});
			},

			/**
			 * Checks whether the hierarchy for the 'currentObjectId' needs to be loaded (This is the case if it is the first
			 * instantiation of the controller or if the 'currentObjectId' has changed). Depending on the result the new data
			 * is retrieved from the backend and binded to the correct table. The backend implementation of the hierarchy is very
			 * different from standard OData Entities. Only modify with utter care.
			 * @public
			 */
			loadHierarchy: function () {
				if (this.getView().needsToLoadHierarchy) {
					this.getView().needsToLoadHierarchy = false;
					this.getView().byId("treeTable").bindRows({
						path: '/HierarchyNodeSet',
						parameters: {
							numberOfExpandedLevels: 1,
							countMode: 'Inline'
						},
						filters: new sap.ui.model.Filter("InitialNodeId", sap.ui.model.FilterOperator.EQ, this.sCurrentId)
					});
				}
			},

			loadEventLocationData: function () {
				if (this.getView().needsToLoadEventLocationData) {
					this.getView().needsToLoadEventLocationData = false;
					var aEventKeys = this.getView().byId("eventsMasterTable").getBinding("items").aAllKeys;
					var iLength = aEventKeys.length;

					var aPromises = [];
					var aMapEvents = [];
					var that = this;
					for (var i = 0; i < iLength; i++) {
						aPromises.push(new Promise(function (resolve, reject) {
							that.getView().getModel().read("/" + aEventKeys[i], {
								urlParameters: { $expand: "GenVal" },
								success: function (oData) {
									var aGenVals = oData.GenVal.results;
									var iiLength = aGenVals.length;
									for (var ii = 0; ii < iiLength; ii++) {
										if (aGenVals[ii].Id === "GEOLOC_LAT") {
											oData.GEOLOC_LAT = parseFloat(aGenVals[ii].TextValue);
										}
										if (aGenVals[ii].Id === "GEOLOC_LON") {
											oData.GEOLOC_LON = parseFloat(aGenVals[ii].TextValue);
										}
									}

									aMapEvents.push(oData);
									resolve();
								},
								error: reject
							});
						}));
					}

					Promise.all(aPromises).then(function () {		
						var sRoute = "";				
						for (var i = 0; i < aMapEvents.length; i++) {
							var oSpots = that.getView().byId("theSpots");
							var oRoutes = that.getView().byId("theRoutes");
							var oEvent = aMapEvents[i];

							if (!!oEvent.GEOLOC_LAT && !!oEvent.GEOLOC_LON) {
								var sPosition = oEvent.GEOLOC_LON + ";" + oEvent.GEOLOC_LAT + ";0";
								oSpots.addItem(new sap.ui.vbm.Spot({
									position: sPosition,
									tooltip: oEvent.Disposition
								}));
								sRoute += ";" + sPosition;
								that.getView().byId("theMap").setCenterPosition(oEvent.GEOLOC_LON + ";" + oEvent.GEOLOC_LAT);
							}							
						}
						oRoutes.addItem(new sap.ui.vbm.Route({
							position: sRoute.substring(1),
							start: "0", 
							 end: "1",
							color: 'rgb(92, 186, 230)',
							tooltip: "the Route"
						}));
					})
				}
			},

			/**
			 * This hook is called after an IconTabBar Tab has been selected that is not part of the standard application.
			 * Use handler onTabChanged in your own controller to implement custom logic for your custom Tabs.
			 * sTabKey can be used to identify the selected Tab.
			 * @public
			 */
			extHook_onTabChanged: function (sTabKey) {
				if (this.onTabChanged) {         			// check whether any extension has implemented the hook...
					this.onTabChanged(sTabKey); 			// ...and call it
				}
			}
		});
	});