/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define([
    "com/sap/cd/sttp/zcockpit/controller/BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "com/sap/cd/sttp/zcockpit/delegate/shared/PersonalizationDelegate",
    "com/sap/cd/sttp/zcockpit/delegate/shared/MasterFilterDelegate"
], function (BaseController, JSONModel, Filter, FilterOperator,
    PersonalizationDelegate, MasterFilterDelegate) {
    "use strict";

    return BaseController.extend("com.sap.cd.sttp.zcockpit.controller.tradeitems.Master", {
        aFilters: [],

        onInit: function () {
            PersonalizationDelegate.initVariantManagementForView("tradeitemsMaster", this.getView());
            PersonalizationDelegate.initTablePersonalizationForView("tradeitemsMaster", this.getView());
        },

        onAfterRendering: function (oEvent) {
            MasterFilterDelegate.registerKeyUp(oEvent);
        }
    });
});