/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
/*!
 * UI development toolkit for HTML5 (OpenUI5)
 * (c) Copyright 2009-2016 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */

sap.ui.define(['jquery.sap.global'],
    function (jQuery) {
        "use strict";

		/**
		 * Slider renderer.
		 * @namespace
		 */
        var DataSliderRenderer = {};

		/**
		 * CSS class to be applied to the HTML root element of the Slider control.
		 *
		 * @type {string}
		 */
        DataSliderRenderer.CSS_CLASS = "sapMSlider";

		/**
		 * Renders the HTML for the given control, using the provided {@link sap.ui.core.RenderManager}.
		 *
		 * @param {sap.ui.core.RenderManager} oRm The RenderManager that can be used for writing to the render output buffer.
		 * @param {sap.ui.core.Control} oSlider An object representation of the slider that should be rendered.
		 */
        DataSliderRenderer.render = function (oRm, oSlider) {
            var bEnabled = oSlider.getEnabled(),
                sTooltip = oSlider.getTooltip_AsString(),
                CSS_CLASS = DataSliderRenderer.CSS_CLASS;

            oRm.write("<div");
            this.addClass(oRm, oSlider);

            if (!bEnabled) {
                oRm.addClass(CSS_CLASS + "Disabled");
            }

            oRm.addStyle("width", oSlider.getWidth());
            oRm.writeClasses();
            oRm.writeStyles();
            oRm.writeControlData(oSlider);

            if (sTooltip && oSlider.getShowHandleTooltip()) {
                oRm.writeAttributeEscaped("title", sTooltip);
            }

            oRm.write(">");
            oRm.write('<div');
            oRm.writeAttribute("id", oSlider.getId() + "-inner");
            this.addInnerClass(oRm, oSlider);

            if (!bEnabled) {
                oRm.addClass(CSS_CLASS + "InnerDisabled");
            }

            oRm.writeClasses();
            oRm.writeStyles();
            oRm.write(">");

            if (oSlider.getProgress()) {
                this.renderProgressIndicator(oRm, oSlider);
            }

            this.renderHandles(oRm, oSlider);
            oRm.write("</div>");

            this.renderTickmarks(oRm, oSlider);

            this.renderLabels(oRm, oSlider);

            if (oSlider.getName()) {
                this.renderInput(oRm, oSlider);
            }

            oRm.write("</div>");
        };

        DataSliderRenderer.renderProgressIndicator = function (oRm, oSlider) {
            oRm.write("<div");
            oRm.writeAttribute("id", oSlider.getId() + "-progress");
            this.addProgressIndicatorClass(oRm, oSlider);
            oRm.addStyle("width", oSlider._sProgressValue);
            oRm.writeClasses();
            oRm.writeStyles();
            oRm.write(' aria-hidden="true"></div>');
        };

		/**
		 * This hook method is reserved for derived classes to render more handles.
		 *
		 * @param {sap.ui.core.RenderManager} oRm The RenderManager that can be used for writing to the render output buffer.
		 * @param {sap.ui.core.Control} oSlider An object representation of the slider that should be rendered.
		 */
        DataSliderRenderer.renderHandles = function (oRm, oSlider) {
            this.renderHandle(oRm, oSlider, {
                id: oSlider.getId() + "-handle"
            });

            if (oSlider.getShowAdvancedTooltip()) {
                this.renderTooltips(oRm, oSlider);
            }
        };

        DataSliderRenderer.renderHandle = function (oRm, oSlider, mOptions) {
            var bEnabled = oSlider.getEnabled();

            oRm.write("<span");

            if (mOptions && (mOptions.id !== undefined)) {
                oRm.writeAttributeEscaped("id", mOptions.id);
            }

            if (oSlider.getShowHandleTooltip() && !oSlider.getShowAdvancedTooltip()) {
                this.writeHandleTooltip(oRm, oSlider);
            }

            this.addHandleClass(oRm, oSlider);
            oRm.addStyle(sap.ui.getCore().getConfiguration().getRTL() ? "right" : "left", oSlider._sProgressValue);
            this.writeAccessibilityState(oRm, oSlider);
            oRm.writeClasses();
            oRm.writeStyles();

            if (bEnabled) {
                oRm.writeAttribute("tabindex", "0");
            }

            oRm.write("></span>");
        };

		/**
		 * This hook method is reserved for derived classes to render more tooltips.
		 *
		 * @param {sap.ui.core.RenderManager} oRm The RenderManager that can be used for writing to the render output buffer.
		 * @param {sap.ui.core.Control} oSlider An object representation of the slider that should be rendered.
		 */
        DataSliderRenderer.renderTooltips = function (oRm, oSlider) {

            // the tooltips container
            oRm.write("<div");
            oRm.writeAttribute("id", oSlider.getId() + "-TooltipsContainer");
            oRm.addClass(DataSliderRenderer.CSS_CLASS + "TooltipContainer");
            oRm.addStyle("left", "0%");
            oRm.addStyle("right", "0%");
            oRm.addStyle("min-width", "0%");
            oRm.writeClasses();
            oRm.writeStyles();
            oRm.write(">");
            this.renderTooltip(oRm, oSlider, oSlider.getInputsAsTooltips());
            oRm.write("</div>");
        };

        DataSliderRenderer.renderTooltip = function (oRm, oSlider, bInput) {
            if (bInput && oSlider._oInputTooltip) {
                oRm.renderControl(oSlider._oInputTooltip.tooltip);
            } else {
                oRm.write("<span");
                oRm.addClass(DataSliderRenderer.CSS_CLASS + "HandleTooltip");
                oRm.addStyle("width", oSlider._iLongestRangeTextWidth + "px");
                oRm.writeAttribute("id", oSlider.getId() + "-Tooltip");

                oRm.writeClasses();
                oRm.writeStyles();
                oRm.write(">");
                oRm.write("</span>");
            }
        };

		/**
		 * Writes the handle tooltip.
		 * To be overwritten by subclasses.
		 *
		 * @param {sap.ui.core.RenderManager} oRm The RenderManager that can be used for writing to the render output buffer.
		 * @param {sap.ui.core.Control} oSlider An object representation of the control that should be rendered.
		 */
        DataSliderRenderer.writeHandleTooltip = function (oRm, oSlider) {
            oRm.writeAttribute("title", oSlider.toFixed(oSlider.getValue()));
        };

        DataSliderRenderer.renderInput = function (oRm, oSlider) {
            oRm.write('<input type="text"');
            oRm.writeAttribute("id", oSlider.getId() + "-input");
            oRm.addClass(DataSliderRenderer.CSS_CLASS + "Input");

            if (!oSlider.getEnabled()) {
                oRm.write("disabled");
            }

            oRm.writeClasses();
            oRm.writeAttributeEscaped("name", oSlider.getName());
            oRm.writeAttribute("value", oSlider.toFixed(oSlider.getValue()));
            oRm.write("/>");
        };

		/**
		 * Writes the accessibility state to the control.
		 * To be overwritten by subclasses.
		 *
		 * @param {sap.ui.core.RenderManager} oRm The RenderManager that can be used for writing to the render output buffer.
		 * @param {sap.ui.core.Control} oSlider An object representation of the control that should be rendered.
		 */
        DataSliderRenderer.writeAccessibilityState = function (oRm, oSlider) {
            oRm.writeAccessibilityState(oSlider, {
                role: "slider",
                orientation: "horizontal",
                valuemin: oSlider.toFixed(oSlider.getMin()),
                valuemax: oSlider.toFixed(oSlider.getMax()),
                valuenow: oSlider.toFixed(oSlider.getValue())
            });
        };

        DataSliderRenderer.renderTickmarks = function (oRm, oSlider) {
            if (!oSlider.getEnableTickmarks()) {
                return;
            }

            oRm.write("<ul class=\"sapMSliderTickmarks\" style=\"z-index: 99;\">");
            oRm.write("<li  class=\"sapMSliderTick\" style=\"width: calc(100% - 1px);\"></li>");
            oRm.write("</ul>");
        };

		/**
		 * This method is reserved for derived classes to add extra CSS classes to the HTML root element of the control.
		 *
		 * @param {sap.ui.core.RenderManager} oRm The RenderManager that can be used for writing to the render output buffer.
		 * @param {sap.ui.core.Control} oSlider An object representation of the control that should be rendered.
		 * @since 1.36
		 */
        DataSliderRenderer.addClass = function (oRm, oSlider) {
            oRm.addClass(DataSliderRenderer.CSS_CLASS);
        };

		/**
		 * This method is reserved for derived classes to add extra CSS classes to the inner element.
		 *
		 * @param {sap.ui.core.RenderManager} oRm The RenderManager that can be used for writing to the render output buffer.
		 * @param {sap.ui.core.Control} oSlider An object representation of the control that should be rendered.
		 * @since 1.38
		 */
        DataSliderRenderer.addInnerClass = function (oRm, oSlider) {
            oRm.addClass(DataSliderRenderer.CSS_CLASS + "Inner");
        };

		/**
		 * This method is reserved for derived classes to add extra CSS classes to the progress indicator element.
		 *
		 * @param {sap.ui.core.RenderManager} oRm The RenderManager that can be used for writing to the render output buffer.
		 * @param {sap.ui.core.Control} oSlider An object representation of the control that should be rendered.
		 * @since 1.38
		 */
        DataSliderRenderer.addProgressIndicatorClass = function (oRm, oSlider) {
            oRm.addClass(DataSliderRenderer.CSS_CLASS + "Progress");
        };

		/**
		 * This method is reserved for derived classes to add extra CSS classes to the handle element.
		 *
		 * @param {sap.ui.core.RenderManager} oRm The RenderManager that can be used for writing to the render output buffer.
		 * @param {sap.ui.core.Control} oSlider An object representation of the control that should be rendered.
		 * @since 1.38
		 */
        DataSliderRenderer.addHandleClass = function (oRm, oSlider) {
            oRm.addClass(DataSliderRenderer.CSS_CLASS + "Handle");
        };

		/**
		 * This hook method is reserved for derived classes to render the labels.
		 *
		 * @param {sap.ui.core.RenderManager} oRm The RenderManager that can be used for writing to the render output buffer.
		 * @param {sap.ui.core.Control} oSlider An object representation of the control that should be rendered.
		 */
        DataSliderRenderer.renderLabels = function (oRm, oSlider) {
            oRm.write("<div");
            oRm.addClass(DataSliderRenderer.CSS_CLASS + "Labels");
            oRm.writeClasses();
            oRm.addStyle("margin-left", "-0.5rem");
            oRm.addStyle("margin-right", "-0.5rem");
            oRm.writeStyles();
            oRm.write(">");

            this.renderAllLabels(oRm, oSlider);

            oRm.write("</div>");
        };

        DataSliderRenderer.renderAllLabels = function (oRm, oSlider) {
            var iMax = oSlider.getMax();
            var aItems = oSlider.getItems();

            for (var i = 0; i <= iMax; i++) {
                oRm.write("<div");
                oRm.addClass(DataSliderRenderer.CSS_CLASS + "RangeLabel");
                oRm.writeClasses();
                oRm.addStyle("width", "1rem");
                oRm.writeStyles();
                oRm.write(">");

                this.writeImgHtml(oRm, oSlider, aItems[i].getKey(), i);

                oRm.write("</div>");
            }
        };

        DataSliderRenderer.writeImgHtml = function(oRm, oSlider, sURI, i) {  
            if (sURI) {
                oRm.renderControl(oSlider._getImage(oSlider.getId() + "-iconSld" + sURI.split("//")[1], sURI));
            }
        };

        return DataSliderRenderer;

    }, /* bExport= */ true);