/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define([
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
 	"sap/ui/core/message/Message",
	"sap/ui/model/Filter",
	"sap/ui/model/Sorter"
], function(Export, ExportTypeCSV, Message, Filter, Sorter) {
	"use strict";

	/**
	 * Shared Delegate for handling the export of data from the master lists.
	 *
	 * @name com.sap.cd.sttp.zcockpit.delegate.shared.ExportDelegate
	 */
	return {
		exportDataFromTable: function(oEvent) {
			var oMessageManager = sap.ui.getCore().getMessageManager();
			oMessageManager.addMessages(
				new Message({
					message: this.getModel("i18n").getProperty("EXPORT_STARTED"),
					type: sap.ui.core.MessageType.Information,
					processor: this.getModel()
				})
			);
			this.getView().byId("btnToggleMsgs").firePress();
			var that = this;
			var oModel = this.getView().getModel();
			var oTable = this.getView().byId("masterTable");
			var oBinding = oTable.getBinding("rows");
			var aFilters = oBinding ? oBinding.aApplicationFilters.slice() : [];

			if (!oBinding || oBinding.getLength() <= 0 ) {
				oMessageManager.addMessages(
					new Message({
						message: this.getModel("i18n").getProperty("EXPORT_WARNING"),
						type: sap.ui.core.MessageType.Warning,
						processor: this.getModel()
					})
				);
				this.getView().byId("btnToggleMsgs").firePress();
				return;
			} else if ( aFilters.length <= 0) {
				oMessageManager.addMessages(
					new Message({
						message: this.getModel("i18n").getProperty("EXPORT_WARNING_NO_FILTER"),
						type: sap.ui.core.MessageType.Warning,
						processor: this.getModel()
					})
				);				
				this.getView().byId("btnToggleMsgs").firePress();
				return;
			}
			
			this.getModel("settings").setProperty("/ShowBusy", true);
			
			var _fnSuccess = function(oResp) {
				if (oResp && oResp.results.length > 0) {
					var sUrl = oResp.results[0].Export;
					var newWin = window.open(sUrl);
					if(!newWin || newWin.closed || typeof newWin.closed=='undefined') { 
						alert(that.getView().getModel("i18n").getProperty("DISABLE_POPUP_BLOCKER"));
					}
				}
				that.getModel("settings").setProperty("/ShowBusy", false);
			}

			var _fnError = function(oError) {
				oMessageManager.addMessages(
					new Message({
						message: that.getModel("i18n").getProperty("EXPORT_TIMEOUT"),
						type: sap.ui.core.MessageType.Error,
						processor: that.getModel()
					})
				);
				that.getModel("settings").setProperty("/ShowBusy", false);
			}


			// Sorters here are used to control in backend which columns shall be exported
			// Customer extension have to be handled seperately
			var aSorters = [],
				aZFields = [],
				aColumns = oTable.getColumns();
			for (var c = 0, len = aColumns.length; c < len; c++) {
				var oColumn = aColumns[c],
					sSortProperty = oColumn.getSortProperty();
				if (oColumn.getVisible() && !!sSortProperty) {
					if (sSortProperty.indexOf("Z_") === 0) {
						aZFields.push(sSortProperty.substr(2));
					} else {
						aSorters.push(new Sorter(sSortProperty));
					}
				}
			}

			var oExportFilter = new Filter("Export", "BT", "X", aZFields.join(","));
			aFilters.push(oExportFilter);

			oModel.read(oBinding.getPath(), {
				filters: aFilters,
				sorters: aSorters,
				success: _fnSuccess,
				error: _fnError
			})
		}
	};
}, true);