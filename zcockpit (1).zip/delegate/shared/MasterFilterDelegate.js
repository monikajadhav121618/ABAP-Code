/* 
 * Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(["com/sap/cd/sttp/zcockpit/model/formatter/FixedValueFormatter",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter"
], function(FixedValueFormatter,
	MessageBox, Filter, FilterOperator, Sorter) {
	"use strict";

	/**
	 * Delegate for handling actions which concern the FilterBar control on the master screens.
	 *
	 * @name com.sap.cd.sttp.zcockpit.delegate.shared.MasterFilterDelegate
	 */
	return {
		/**
		 * Handler for performing the final search after specifying filter criteria in the FilterBar. The values from the
		 * input fields and drop downs are passed into sap.ui.model.Filters with the 'EQ' operator. Beforehand there is an
		 * exception check performed for 'Doctpe', because it is only a valid filter criteria when in conjunction with a
		 * specified value for 'Docnum'. After passing all filter criteria to the backend the newly retrieved data set is
		 * bound to the master table.
		 * @public
		 */
		getSerialNumber: function(oEvent) {
			var oMasterTable = this.byId("masterTable"),
				aFilters = [],
				oFilter;
			var oBindingContext = oEvent.getSource().getBindingContext();

			aFilters.push(new Filter('Gtin', "EQ", oBindingContext.getProperty("Gtin")));
			aFilters.push(new Filter('Lotno', "EQ", oBindingContext.getProperty("Lotno")));
			oFilter = new Filter(aFilters, true);
			oMasterTable.bindRows({
				path: "/ObjItemSet",
				parameters: {
					expand: "Attrib"
				}, // Required for customer extensions
				filters: aFilters.length > 0 ? oFilter : undefined,
				events: {
					dataReceived: function() {
						oMasterTable.setBusy(false);
					}
				}
			});
		},
		onSearch: function (oEvent) {
				var oMasterTable = this.byId("masterTable"),
					persKey = oEvent.getSource().getPersistencyKey(),
					that = this,
					bIsDocnum = false,
					bCancel = false,
					mTimeRange = {},
					aFilters = [],
					oDateFormat,
					oFilter;

				$.each(oEvent.getParameter("selectionSet"), function (iIndex, oItem) {
					if (oItem.getValueState && oItem.getValueState() === "Error") {
						MessageBox.show(oItem.getValueStateText(), {
							icon: MessageBox.Icon.WARNING,
							title: that.getView().getModel("i18n").getProperty("WARNING")
						});
						bCancel = true;
						return;
					}

					if (oItem instanceof sap.m.Input && oItem.getValue().length > 0) {
						// Docnum entered? 
						bIsDocnum = oItem.getName() === "Docnum";
						aFilters.push(new Filter(oItem.getName(), "EQ", oItem.getValue()));
					}

					if (oItem instanceof sap.m.DateRangeSelection && oItem.getValue().length > 0) {
						oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
							pattern: "yyyy-MM-dd"
						});

						aFilters.push(new Filter(oItem.getName(), "BT", oDateFormat.format(oItem.getDateValue()),
							oDateFormat.format(oItem.getSecondDateValue())));
					}

					if (oItem instanceof sap.m.DateTimeInput && oItem.getValue().length > 0) {
						var aSplit = oItem.getName().split("_");
						if (!(aSplit[0] in mTimeRange)) {
							mTimeRange[aSplit[0]] = {};
						}
						mTimeRange[aSplit[0]][aSplit[1]] = oItem.getValue();
					}

					if (oItem instanceof sap.m.Select && oItem.getSelectedKey().length > 0) {
						// Doctpe only allowed with Docnum
						if (oItem.getName() === "Doctpe" && persKey === "filterbarObjects" && !bIsDocnum) {
							MessageBox.show(that.getView().getModel("i18n").getProperty("SEARCH_DOCNUM_REQUIRED"), {
								icon: MessageBox.Icon.Warning,
								title: that.getView().getModel("i18n").getProperty("WARNING")
							});
							bCancel = true;
						} else {
							aFilters.push(new Filter(oItem.getName(), "EQ", oItem.getSelectedKey()));
						}
					}

					if (oItem instanceof sap.m.CheckBox && oItem.getSelected()) {
						// only limit results, if actually selected
						if (oItem.getName() === "ResponsesOpen") {
							aFilters.push(new Filter(oItem.getName(), "GE", 1));
						} else {
							aFilters.push(new Filter(oItem.getName(), "EQ", 'X'));
						}
					}
				});

				for (var key in mTimeRange) {
					if (mTimeRange.hasOwnProperty(key)) {
						oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
							pattern: "yyyyMMddHHmmss"
						});
						// Time ranges only allowed if From and To is given
						if (mTimeRange[key]["From"] && mTimeRange[key]["To"]
							&& mTimeRange[key]["From"] < mTimeRange[key]["To"]) {
							var sFrom = key === "Evttime" ? oDateFormat.parse(mTimeRange[key]["From"], true) : oDateFormat.parse(mTimeRange[key]["From"]);
							var sTo = key === "Evttime" ? oDateFormat.parse(mTimeRange[key]["To"], true) : oDateFormat.parse(mTimeRange[key]["To"]);
							aFilters.push(new Filter(key, "BT", sFrom, sTo));
						} else {
							MessageBox.show(that.getView().getModel("i18n").getProperty("SEARCH_TIME_REQUIRED"), {
								icon: MessageBox.Icon.Warning,
								title: that.getView().getModel("i18n").getProperty("WARNING")
							});
							bCancel = true;
						}
					}
				}


				if (bCancel) {
					return;
				}

				oFilter = new Filter(aFilters, true);
				
				oMasterTable.setBusy(true);
				oMasterTable.bindRows({
					path: oEvent.getSource().data("entitySet"),
					parameters: { expand: "Attrib" }, // Required for customer extensions
					filters: aFilters.length > 0 ? oFilter : undefined,
					events: {
						dataReceived: function() {
							oMasterTable.setBusy(false);
						}
					}
				});
			},
		onSearch1: function(oEvent) {
			var oMasterTable = this.byId("masterTable"),
				oMasterTable2 = this.byId("masterTable2"),
				persKey = oEvent.getSource().getPersistencyKey(),
				that = this,
				bIsDocnum = false,
				bCancel = false,
				mTimeRange = {},
				aFilters = [],
				oDateFormat,
				oFilter;
			oMasterTable2.unbindRows();
			oMasterTable.unbindRows();
			$.each(oEvent.getParameter("selectionSet"), function(iIndex, oItem) {
				if (oItem.getValueState && oItem.getValueState() === "Error") {
					MessageBox.show(oItem.getValueStateText(), {
						icon: MessageBox.Icon.WARNING,
						title: that.getView().getModel("i18n").getProperty("WARNING")
					});
					bCancel = true;
					return;
				}

				if (oItem instanceof sap.m.Input && oItem.getValue().length > 0) {
					// Docnum entered? 
					bIsDocnum = oItem.getName() === "Docnum";
					aFilters.push(new Filter(oItem.getName(), "EQ", oItem.getValue()));
				}

				if (oItem instanceof sap.m.DateRangeSelection && oItem.getValue().length > 0) {
					oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "yyyy-MM-dd"
					});

					aFilters.push(new Filter(oItem.getName(), "BT", oDateFormat.format(oItem.getDateValue()),
						oDateFormat.format(oItem.getSecondDateValue())));
				}

				if (oItem instanceof sap.m.DateTimeInput && oItem.getValue().length > 0) {
					var aSplit = oItem.getName().split("_");
					if (!(aSplit[0] in mTimeRange)) {
						mTimeRange[aSplit[0]] = {};
					}
					mTimeRange[aSplit[0]][aSplit[1]] = oItem.getValue();
				}

				if (oItem instanceof sap.m.Select && oItem.getSelectedKey().length > 0) {
					// Doctpe only allowed with Docnum
					if (oItem.getName() === "Doctpe" && persKey === "filterbarObjects" && !bIsDocnum) {
						MessageBox.show(that.getView().getModel("i18n").getProperty("SEARCH_DOCNUM_REQUIRED"), {
							icon: MessageBox.Icon.Warning,
							title: that.getView().getModel("i18n").getProperty("WARNING")
						});
						bCancel = true;
					} else {
						aFilters.push(new Filter(oItem.getName(), "EQ", oItem.getSelectedKey()));
					}
				}

				if (oItem instanceof sap.m.CheckBox && oItem.getSelected()) {
					// only limit results, if actually selected
					if (oItem.getName() === "ResponsesOpen") {
						aFilters.push(new Filter(oItem.getName(), "GE", 1));
					} else {
						aFilters.push(new Filter(oItem.getName(), "EQ", 'X'));
					}
				}
			});

			for (var key in mTimeRange) {
				if (mTimeRange.hasOwnProperty(key)) {
					oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "yyyyMMddHHmmss"
					});
					// Time ranges only allowed if From and To is given
					if (mTimeRange[key]["From"] && mTimeRange[key]["To"] && mTimeRange[key]["From"] < mTimeRange[key]["To"]) {
						var sFrom = key === "Evttime" ? oDateFormat.parse(mTimeRange[key]["From"], true) : oDateFormat.parse(mTimeRange[key]["From"]);
						var sTo = key === "Evttime" ? oDateFormat.parse(mTimeRange[key]["To"], true) : oDateFormat.parse(mTimeRange[key]["To"]);
						aFilters.push(new Filter(key, "BT", sFrom, sTo));
					} else {
						MessageBox.show(that.getView().getModel("i18n").getProperty("SEARCH_TIME_REQUIRED"), {
							icon: MessageBox.Icon.Warning,
							title: that.getView().getModel("i18n").getProperty("WARNING")
						});
						bCancel = true;
					}
				}
			}

			if (bCancel) {
				return;
			}

			oFilter = new Filter(aFilters, true);

			/*oMasterTable.setBusy(true);
			oMasterTable.bindRows({
				path: oEvent.getSource().data("entitySet"),
				parameters: { expand: "Attrib" }, // Required for customer extensions
				filters: aFilters.length > 0 ? oFilter : undefined,
				events: {
					dataReceived: function() {
						oMasterTable.setBusy(false);
					}
				}
			});*/
			//oMasterTable2.setBusy(true);
			oMasterTable2.setModel(this.getView().getModel("gtin")); 
			oMasterTable2.bindRows({
				path: "/zcockpitSet",
				filters: aFilters.length > 0 ? oFilter : undefined,
				events: {
					dataReceived: function() {
						//		oMasterTable.setBusy(false);
					}
				}
			});
		},

		/**
		 * Clears all input fields and all drop downs of the filter bar.
		 * @public
		 */
		onClear: function(oEvent) {
			var oMasterTable = this.byId("masterTable"),
				oMasterTable2 = this.byId("masterTable2");
			oMasterTable2.unbindRows();
			oMasterTable.unbindRows();
			$.each(oEvent.getParameter("selectionSet"), function(iIndex, oItem) {
				if (oItem.getValue && oItem.getValue().length > 0) {
					oItem.setValue(null);
				}

				if (oItem.getSelectedKey && oItem.getSelectedKey().length > 0) {
					oItem.setSelectedKey(null);
				}

				if (oItem.getSelected && oItem.getSelected()) {
					oItem.setSelected(false);
				}
			});
		},

		/**
		 * Joint handler for pressing a value help button in the FilterBar. Depending on a custom data attribute
		 * which is attached to the event source control this function opens the value help dialog and instantiates
		 * the correct fragment. There is an exception for the Gtin value help, because the Gtin value help dialog
		 * has an own delegate with slightly more complex functionality.
		 * @public
		 */
		handleValueHelpRequest: function(oEvent) {
			this._valueHelpSource = oEvent.getSource();
			if (this._valueHelpSource.getName() === "Gtin") {
				this._valueHelpDialog = this.getDelegate("Gtin");
				this._valueHelpDialog.open(this._valueHelpSource);
			} else {
				var sFragment = this._valueHelpSource.data("fragment") ? this._valueHelpSource.data("fragment") : this._valueHelpSource.getName();
				this._valueHelpDialog = sap.ui.xmlfragment(
					"com.sap.cd.sttp.zcockpit.fragment.shared.valueHelp." + sFragment, this);
				this.getView().addDependent(this._valueHelpDialog);
				this._valueHelpDialog.addStyleClass("sapUiSizeCompact");
				this._valueHelpDialog.open();
			}
		},

		/**
		 * Joint handler for selecting an item from the value help dialog. It takes the leading attribute and passes
		 * it inside the actual input field of the FilterBar. Afterwards it notices the Variant Management that a
		 * change has occured. This is necessary for the user to be able to subsequently save the variant.
		 * @public
		 */
		handleValueHelpClose: function(oEvent) {
			var oSelectedValue = oEvent.getParameter("selectedItem").getTitle();
			this._valueHelpSource.setValue(oSelectedValue);
			this.getView().byId("filterbar")._oVariantManagement.currentVariantSetModified(true);
		},

		/**
		 * Joint handler for performing a search in the value help dialog. Depending on the involved entity different
		 * filter criteria have to be set. 
		 * @public
		 */
		handleValueHelpSearch: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var bIsDescrValue = false; // filter value may not exceed field length
			var sKey1, sKey2, sKey3;

			var oBinding = oEvent.getParameter("itemsBinding");
			var sPath = oBinding.getPath();
			if (sPath.startsWith("/ShlpGtin")) {
				sKey1 = "Gtin";
				sKey2 = "Text";
				bIsDescrValue = sValue.length > 14;
			} else if (sPath.startsWith("/ShlpDisposition")) {
				sKey1 = "Dispno";
				sKey2 = "Dispcode";
				bIsDescrValue = sValue.length > 3;
			} else if (sPath.startsWith("/ShlpBizstep")) {
				sKey1 = "Bizstepno";
				sKey2 = "Bizstepcode";
				bIsDescrValue = sValue.length > 3;
			} else if (sPath.startsWith("/ShlpUser")) {
				sKey1 = "Firstname";
				sKey2 = "Lastname";
				bIsDescrValue = false;
			} else if (sPath.startsWith("/ShlpNCode")) {
				sKey1 = "NCode";
				sKey2 = "Text";
				sKey3 = "Gtin";
				bIsDescrValue = false;
			} else if (sPath.startsWith("/ShlpRCode")) {
				sKey1 = "RCode";
				sKey2 = "Text";
				sKey3 = "Gtin";
				bIsDescrValue = false;
			} else if (sPath.startsWith("/ShlpRuleType")) {
				sKey1 = "RuleType";
				sKey2 = "RuleTypeDescr";
				bIsDescrValue = false;
			} else if (sPath.startsWith("/ShlpNotifType")) {
				sKey1 = "NotifType";
				sKey2 = "NotifTypeDescr";
				bIsDescrValue = false;
			}

			var oFilter = new Filter(sKey1, FilterOperator.Contains, sValue);
			var oFilter2 = new Filter(sKey2, FilterOperator.Contains, sValue);
			var oFilter3 = new Filter(sKey3, FilterOperator.Contains, sValue);

			if (bIsDescrValue) {
				oBinding.filter(new Filter([oFilter2], false));
			} else {
				var aFinalFilters = [oFilter, oFilter2];
				if (sKey3) {
					aFinalFilters.push(oFilter3);
				}
				oBinding.filter(new Filter(aFinalFilters, false));
			}

			/*var oSorter = new Sorter(sKey1, false);
			oBinding.sort(oSorter);*/
		},

		/**
		 * Somehow experimental implementation of registering the keyUp event of the "Enter"-key. In case the user
		 * has focus on the page pressing the "Enter"-key invokes the 'search' method of the filter bar.
		 * @public
		 */
		registerKeyUp: function(oEvent) {
			/*var oView = oEvent.getSource();
			oView.$().bind("keyup", $.proxy(function(e) {
				var code = e.which;
				if (code === 13) { // ENTER
					e.preventDefault();
					oView.byId("filterbar").search();
				}
			}));*/
		}
	};
}, true);