/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define(['sap/m/Button',
	'sap/m/Dialog',
	"sap/m/Input",
	'sap/m/MessageToast',
	'sap/m/Text',
	'sap/m/TextArea',
	'sap/ui/core/mvc/Controller',
	'sap/ui/layout/HorizontalLayout',
	'sap/ui/layout/VerticalLayout',
	'sap/ui/model/json/JSONModel',
	'com/sap/cd/sttp/zcockpit/util/BackendHelper',
	'com/sap/cd/sttp/zcockpit/lib/epcismessageprovider/EPCISMessageProvider',
	'com/sap/cd/sttp/zcockpit/lib/scanprovider/ScanProvider',
	'com/sap/cd/sttp/zcockpit/model/formatter/FixedValueFormatter',
	'com/sap/cd/sttp/zcockpit/model/formatter/EPCISFormatter',
], function (Button, Dialog, Input, MessageToast, Text, TextArea, Controller,
	HorizontalLayout, VerticalLayout, JSONModel, BackendHelper, EPCISMessageProvider,
	ScanProvider, FixedValueFormatter, EPCISFormatter) {
		"use strict";

		var createErrorDialog = function (oData) {
			var that = this;
			var aMessages = JSON.parse(oData.d.results[0].json_ctx).JSON_CTX.MESSAGES;
			var oDialog = sap.ui.xmlfragment("com.sap.cd.sttp.zcockpit.fragment.shared.epcis.dialog.Messages", this);
			oDialog.getBeginButton().attachPress(function () {
				oDialog.close();
			});
			oDialog.attachAfterClose(function () {
				oDialog.destroy();
				oDialog.getModel("dialog").destroy();
				that.getView().getObjectBinding().refresh();
			});
			this.getView().addDependent(oDialog);
			oDialog.setModel(new JSONModel({
				"messages": aMessages,
				"lastMessage": aMessages[aMessages.length - 1]
			}), "dialog");
			oDialog.open();
		};

		var createDialog = function (sFragmentName, oDialogModel) {
			var oDialog = sap.ui.xmlfragment("com.sap.cd.sttp.zcockpit.fragment.shared.epcis.dialog." + sFragmentName, this);
			var that = this;
			this.getView().addDependent(oDialog);
			oDialog.setModel(oDialogModel, "dialog");
			oDialog.getBeginButton().attachPress(function () {
				oDialog.close();
			});
			oDialog.getEndButton().attachPress(function () {
				oDialog.close();
			});
			oDialog.attachAfterClose(function () {
				oDialog.destroy();
				oDialog.getModel("dialog").destroy();
			});
			oDialog.open();
			return oDialog;
		};

		var initProvider = function () {
			var that = this;
			this.oProvider = new EPCISMessageProvider({
				url: "/sap/opu/odata/sttp/warehouse_service_srv",
				callerUser: "",
				callerSystem: "",
				syncCall: true,
				proxyNS: "none", //urn:sap.com:proxy:X3N:/1SAI/TAE4350B0DB1E861B094F2E:740",
				sapQueueMessageSender: "WEB_COCKPIT",
				readPoint: "", // set in sendEvent
				bizLocation: "" // set in sendEvent
			});
		};

		var _getObjectFromBackend = function (sParent) {
			return BackendHelper.getInferredObject(sParent);
		};




		/**
		 * Delegate API for handling user's intention to post an atomic EPCIS event. This delegate recognizes
		 * different types of EPCIS Events, opens corresponding Dialogs and invokes EPCIS XML creation.
		 *
		 * @name com.sap.cd.sttp.zcockpit.delegate.shared.epcis.EPCISDelegate
		 */
		return {
			checkAuthenticationForEPCISActions: function (sGln) {
				var that = this;
				this.getView().getModel().read("/GetGlnAssignment", {
					urlParameters: {
						"Gln": "'" + sGln + "'"
					},
					success: function (oResult) {
						var oHeader = that.getView().byId("pageHeader");
						var bHasAuth = oResult.TextValue === 'X';
						that.getView().getModel("config").setProperty("/hasAuth", bHasAuth);
						that.getView().byId("ObjectPageHeader-overflow") && that.getView().byId("ObjectPageHeader-overflow").setEnabled(bHasAuth);
						oHeader.invalidate();
					}
				})
			},

			/**
			 * Displays the user-defined menu of avaiable atomic EPCIS Events.
			 * @public
			 */
			showActionSheet: function (oEvent) {
				var oActionSheet = sap.ui.xmlfragment("com.sap.cd.sttp.zcockpit.fragment.shared.epcis.dialog.ActionSheet", this.getView().getController());
				this.getView().addDependent(oActionSheet);
				oActionSheet.openBy(oEvent.getSource());
			},

			/**
			 * Distinguishes different types of Events and calls corresponding handler.
			 * @public
			 */
			handleAction: function (oEvent) {
				var oCurrentObject = oEvent.getSource().getBindingContext().getObject();
				var oCurrentLoc = {
					"locno": oCurrentObject.Locno,
					"loc_name": oCurrentObject.LocDescr,
					"sgln": oCurrentObject.EpcIdUriLoc
				};
				var oActionConfig = oEvent.getSource().getBindingContext("config").getObject();
				var me = com.sap.cd.sttp.zcockpit.delegate.shared.epcis.EPCISDelegate;
				// add current location to config model
				this.getView().getModel("config").setProperty("/readpnts/0", oCurrentLoc);
				this.getView().getModel("config").setProperty("/bizlocs/1", oCurrentLoc);
				if ($.inArray(oActionConfig.evtid.charAt(0), ["X", "Y", "Z"]) >= 0) {
					// is customer defined action
					me.handleObjectEvent.bind(this)(oCurrentObject, oActionConfig);
				} else {
					// is SAP defined action
					// identify and assign to handler
					var key = oActionConfig.evttype + "-" + oActionConfig.evtaction;
					switch (key) {
						case "ObjectEvent-OBSERVE":
						case "ObjectEvent-ADD":
						case "ObjectEvent-DELETE":
							me.handleObjectEvent.bind(this)(oCurrentObject, oActionConfig);
							break;
						case "AggregationEvent-ADD":
							me.handleAggregateEvent.bind(this)(oCurrentObject, oActionConfig);
							break;
						case "AggregationEvent-DELETE":
							me.handleDisaggregateEvent.bind(this)(oCurrentObject, oActionConfig);
							break;
						case "TransactionEvent-ADD":
							me.handleAddTransactionEvent.bind(this)(oCurrentObject, oActionConfig);
							break;
						case "TransactionEvent-DELETE":
							me.handleRemoveTransactionEvent.bind(this)(oCurrentObject, oActionConfig);
							break;
					}
				}
			},

			handleObjectEvent: function (oCurrentObject, oActionConfig) {
				this.oProvider || initProvider.bind(this)();
				var oDialogModel = new JSONModel({
					"Object": oCurrentObject.Gs1EsB,
					"Type": oActionConfig.evtname,
					"ReadPoint": oCurrentObject.EpcIdUriLoc, 	//default current
					"BizLoc": oCurrentObject.EpcIdUriLoc, 		//default current
					"readpt_sel": oActionConfig.readpt_sel === 'X',
					"bizloc_sel": oActionConfig.bizloc_sel === 'X',
					"biztr_sel": oActionConfig.biztr_sel === 'X',
					"Bizttype": "",
					"Trncode": ""
				});
				var oDialog = createDialog.bind(this)("StandardConfirm", oDialogModel);
				var that = this;
				oDialog.getBeginButton().attachPress(function () {
					that.oProvider.sendEvent(oActionConfig, {
						epcIdUri: oCurrentObject.EpcIdUri,
						epcIdUriLoc: oDialogModel.getProperty("/ReadPoint"),
						epcIdUriLocBiz: oDialogModel.getProperty("/BizLoc"),
						trnType: EPCISFormatter.TrnTypeToEpc(oDialogModel.getProperty("/Bizttype")),
						trnCode: oDialogModel.getProperty("/Trncode"),
						success: createErrorDialog.bind(that),
						error: createErrorDialog.bind(that)
					});
				});
			},

			handleAddTransactionEvent: function (oCurrentObject, oActionConfig) {
				this.oProvider || initProvider.bind(this)();
				var oDialogModel = new JSONModel({
					"Object": oCurrentObject.Gs1EsB,
					"Type": oActionConfig.evtname,
					"ReadPoint": oCurrentObject.EpcIdUriLoc, 	//default current
					"BizLoc": oCurrentObject.EpcIdUriLoc, 		//default current
					"readpt_sel": oActionConfig.readpt_sel === 'X',
					"bizloc_sel": oActionConfig.bizloc_sel === 'X',
					"Bizttype": "",
					"Trncode": ""
				});
				var oDialog = createDialog.bind(this)("TransactionConfirm", oDialogModel);
				var that = this;
				oDialog.getBeginButton().attachPress(function () {
					that.oProvider.sendEvent(oActionConfig, {
						epcIdUri: oCurrentObject.EpcIdUri,
						epcIdUriLoc: oDialogModel.getProperty("/ReadPoint"),
						epcIdUriLocBiz: oDialogModel.getProperty("/BizLoc"),
						trnType: EPCISFormatter.TrnTypeToEpc(oDialogModel.getProperty("/Bizttype")),
						trnCode: oDialogModel.getProperty("/Trncode"),
						success: createErrorDialog.bind(that),
						error: createErrorDialog.bind(that)
					});
				});
			},

			handleRemoveTransactionEvent: function (oCurrentObject, oActionConfig) {
				this.oProvider || initProvider.bind(this)();
				var aAvTrns = oCurrentObject.Trn.__list.map(function (sPath) {
					return sap.ui.getCore().getOwnerComponent().getModel().getProperty("/" + sPath);
				});
				var oDialogModel = new JSONModel({
					"Object": oCurrentObject.Gs1EsB,
					"Type": oActionConfig.evtname,
					"ReadPoint": oCurrentObject.EpcIdUriLoc, 	//default current
					"BizLoc": oCurrentObject.EpcIdUriLoc, 		//default current
					"readpt_sel": oActionConfig.readpt_sel === 'X',
					"bizloc_sel": oActionConfig.bizloc_sel === 'X',
					"Bizttype": "",
					"Trncode": "",
					"AvTransactions": aAvTrns
				});
				var oDialog = createDialog.bind(this)("RemoveTransactionConfirm", oDialogModel);
				var that = this;
				oDialog.getBeginButton().attachPress(function () {
					var sTrnCode = oDialogModel.getProperty("/Trncode");
					var sBizttype = "";

					for (var t in aAvTrns) {
						if (aAvTrns[t].Trncode === sTrnCode) {
							sBizttype = FixedValueFormatter.FixedValueBizTrnType.bind(that)(aAvTrns[t].Bizttype);
						}
					}
					that.oProvider.sendEvent(oActionConfig, {
						epcIdUri: oCurrentObject.EpcIdUri,
						epcIdUriLoc: oDialogModel.getProperty("/ReadPoint"),
						epcIdUriLocBiz: oDialogModel.getProperty("/BizLoc"),
						trnType: EPCISFormatter.TrnTypeToEpc(sBizttype),
						trnCode: sTrnCode,
						success: createErrorDialog.bind(that)
					});
				});
			},

			handleDisaggregateEvent: function (oCurrentObject, oActionConfig) {
				this.oProvider || initProvider.bind(this)();
				var that = this;

				this.getView().getModel().read(this.getView().getBindingContext().getPath(), {
					urlParameters: { "$expand": "AggrHierarchy" },
					success: $.proxy(function (oData) {
						try {
							var oParent;
							var aResults = oData.AggrHierarchy.results;
							for (var i=0,len=aResults.length; i < len; i++) {
								if (aResults[i].IsParent === 'X')
								 oParent = aResults[i];
							}

							if (!oParent || !oParent.Description) throw true;

							var oDialogModel = new JSONModel({
								"Object": oCurrentObject.Gs1EsB,
								"Type": oActionConfig.evtname,
								"ReadPoint": oCurrentObject.EpcIdUriLoc, 	//default current
								"BizLoc": oCurrentObject.EpcIdUriLoc, 		//default current
								"readpt_sel": oActionConfig.readpt_sel === 'X',
								"bizloc_sel": oActionConfig.bizloc_sel === 'X',
								"Parent": oParent.RootId
							});
							var oDialog = createDialog.bind(that)("DisaggregateConfirm", oDialogModel);
							oDialog.getBeginButton().attachPress(function () {
								that.oProvider.sendEvent(oActionConfig, {
									epcIdUriChild: oCurrentObject.EpcIdUri,
									epcIdUriPar: oParent.Description,
									epcIdUriLoc: oDialogModel.getProperty("/ReadPoint"),
									epcIdUriLocBiz: oDialogModel.getProperty("/BizLoc"),
									success: createErrorDialog.bind(that),
									error: createErrorDialog.bind(that)
								});
							});
						} catch (ex) {
							MessageToast.show(that.getView().getModel("i18n").getProperty("TOAST_NO_PARENT"));
						}
					}),
					error: function () {
						MessageToast.show(that.getView().getModel("i18n").getProperty("TOAST_CANCELLED"));
					}
				});
			},

			handleAggregateEvent: function (oCurrentObject, oActionConfig) {
				var that = this;
				
				if (oCurrentObject.StatusPack !== 0) {
					MessageToast.show(that.getView().getModel("i18n").getProperty("TOAST_HAS_PARENT"));
					return;
				}

				ScanProvider.scan().then(function (oResult) {
					return _getObjectFromBackend.bind(that)(oResult.text);
				}).then(function (oHelperResult) {
					var oParent = oHelperResult.data;

					if (oParent.Gs1EsB === oCurrentObject.Gs1EsB) {
						MessageToast.show(that.getView().getModel("i18n").getProperty("TOAST_PACK_SELF"));
						return;
					}
					
					that.oProvider || initProvider.bind(that)();
					var oDialogModel = new JSONModel({
						"Object": oCurrentObject.Gs1EsB,
						"Type": oActionConfig.evtname,
						"ReadPoint": oCurrentObject.EpcIdUriLoc, 	//default current
						"BizLoc": oCurrentObject.EpcIdUriLoc, 		//default current
						"readpt_sel": oActionConfig.readpt_sel === 'X',
						"bizloc_sel": oActionConfig.bizloc_sel === 'X',
						"Parent": oParent.Gs1EsB
					});
					var oDialog = createDialog.bind(that)("AggregateConfirm", oDialogModel);
					oDialog.getBeginButton().attachPress(function () {
						that.oProvider.sendEvent(oActionConfig, {
							epcIdUriChild: oCurrentObject.EpcIdUri,
							epcIdUriPar: oParent.EpcIdUri,
							epcIdUriLoc: oDialogModel.getProperty("/ReadPoint"),
							epcIdUriLocBiz: oDialogModel.getProperty("/BizLoc"),
							success: createErrorDialog.bind(that),
							error: createErrorDialog.bind(that)
						});
					});
				}).catch(function (oError) {
					MessageToast.show(that.getView().getModel("i18n").getProperty("TOAST_CANCELLED"));
				});
			}
		};
	}, true);