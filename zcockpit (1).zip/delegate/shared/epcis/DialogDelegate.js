/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define(["sap/ui/model/Filter"], function (Filter) {
    "use strict";

    /**
	 * Delegate for handling the different dialogs which are used to let the user add information to
     * atomic EPCIS events. The dialog model is used to hold the given data and return it to the EPCIS
     * Delegatem, which then forwards it to the EPCIS Message Provider.
	 *
	 * @name com.sap.cd.sttp.zcockpit.delegate.shared.epcis.DialogDelegate
	 */
    return {
        handleValueHelpRequestTrn: function (oEvent) {
            this._valueHelpSource = oEvent.getSource();
            this._valueHelpDialog = sap.ui.xmlfragment("com.sap.cd.sttp.zcockpit.fragment.shared.epcis.valueHelp.ShlpTransaction", this);
            this._valueHelpDialog.getAggregation("_dialog").getSubHeader().setVisible(false);
            this._valueHelpDialog.setModel(oEvent.getSource().getModel("dialog"), "dialog");
            this._valueHelpDialog.setModel(oEvent.getSource().getModel("i18n"), "i18n");
            this._valueHelpDialog.open();
        },

        handleValueHelpRequestDocnum: function (oEvent) {
            this._valueHelpSource = oEvent.getSource();
            this._valueHelpDialog = sap.ui.xmlfragment("com.sap.cd.sttp.zcockpit.fragment.shared.epcis.valueHelp.ShlpDocnum", this);
            this._valueHelpDialog.setModel(oEvent.getSource().getModel());
            this._valueHelpDialog.setModel(oEvent.getSource().getModel("dialog"), "dialog");
            this._valueHelpDialog.setModel(oEvent.getSource().getModel("i18n"), "i18n");

            var sBizttype = oEvent.getSource().getModel("dialog").getProperty("/Bizttype");
            var sTerm = oEvent.getSource().getValue();
            var aFilters = [];
            aFilters.push(new Filter("Docnum", "Contains", sTerm));
            aFilters.push(new Filter("Bizttype", "EQ", sBizttype));
            this._valueHelpDialog.getBinding("items").filter(aFilters);
            this._valueHelpDialog.open(sTerm);
        },

        handleValueHelpRequestReadpt: function (oEvent) {
            this._valueHelpSource = oEvent.getSource();
            this._valueHelpDialog = sap.ui.xmlfragment("com.sap.cd.sttp.zcockpit.fragment.shared.epcis.valueHelp.ShlpReadpoint", this);
            this._valueHelpDialog.getAggregation("_dialog").getSubHeader().setVisible(false);
            this._valueHelpDialog.setModel(oEvent.getSource().getModel("dialog"), "dialog");
            this._valueHelpDialog.setModel(oEvent.getSource().getModel("i18n"), "i18n");
            this._valueHelpDialog.setModel(oEvent.getSource().getModel("config"), "config");
            this._valueHelpDialog.open();
        },

        handleValueHelpRequestBizloc: function (oEvent) {
            this._valueHelpSource = oEvent.getSource();
            this._valueHelpDialog = sap.ui.xmlfragment("com.sap.cd.sttp.zcockpit.fragment.shared.epcis.valueHelp.ShlpBizloc", this);           
            this._valueHelpDialog.getAggregation("_dialog").getSubHeader().setVisible(false);
            this._valueHelpDialog.setModel(oEvent.getSource().getModel("dialog"), "dialog");
            this._valueHelpDialog.setModel(oEvent.getSource().getModel("i18n"), "i18n");
            this._valueHelpDialog.setModel(oEvent.getSource().getModel("config"), "config");
            this._valueHelpDialog.open();
        },

        handleValueHelpCloseTrn: function (oEvent) {
            var sTrncode = oEvent.getParameter("selectedItem").getBindingContext("dialog").getObject().Trncode,
                sBizttype = oEvent.getParameter("selectedItem").getBindingContext("dialog").getObject().Bizttype;

            this._valueHelpSource.getModel("dialog").setProperty("/Trncode", sTrncode);
            this._valueHelpSource.getModel("dialog").setProperty("/Bizttype", sBizttype);
        },

        handleValueHelpCloseDocnum: function (oEvent) {
            var sDocnum = oEvent.getParameter("selectedItem").getBindingContext().getObject().Docnum,
                sTrncode = oEvent.getParameter("selectedItem").getBindingContext().getObject().Trncode;

            this._valueHelpSource.getModel("dialog").setProperty("/Docnum", sDocnum);
            this._valueHelpSource.getModel("dialog").setProperty("/Trncode", sTrncode);
        },

        handleValueHelpSearchDocnum: function (oEvent) {
            var sTerm = oEvent.getParameter("value");
            var sBizttype = oEvent.getSource().getModel("dialog").getProperty("/Bizttype");
            if (sTerm.length > 1) {
                var aFilters = [];
                aFilters.push(new Filter("Docnum", "Contains", sTerm));
                aFilters.push(new Filter("Bizttype", "EQ", sBizttype));
                oEvent.getParameter("itemsBinding").filter(aFilters);
            }
        },

        handleValueHelpCloseReadpt: function (oEvent) {
            var sSgln = oEvent.getParameter("selectedItem").getBindingContext("config").getObject().sgln;
            this._valueHelpSource.getModel("dialog").setProperty("/ReadPoint", sSgln);
        },

        handleValueHelpCloseBizloc: function (oEvent) {
            var sSgln = oEvent.getParameter("selectedItem").getBindingContext("config").getObject().sgln;
            this._valueHelpSource.getModel("dialog").setProperty("/BizLoc", sSgln);
        },

        handleTrnTypeChange: function (oEvent) {
            var oDialogModel = oEvent.getSource().getParent().getModel("dialog");
            if (!oDialogModel.getProperty("Docnum")) {
                oDialogModel.setProperty("/Docnum", "");
                oDialogModel.setProperty("/Trncode", "");
            }
        }
    }
}, true);