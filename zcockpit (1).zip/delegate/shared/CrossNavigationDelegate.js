/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define(["sap/ui/core/routing/History"], function(History) {
	"use strict";

	/**
	 * Delegate for handling any kind of navigation that is shared by different views/pages.
	 *
	 * @name com.sap.cd.sttp.zcockpit.delegate.shared.CrossNavigationDelegate
	 */
	return {

		/**
		 * Navigates to the previous entry in history or to the Fiori launchpad if no history entry exists.
		 * @public
		 */
		navBackFromMaster: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined /*|| !oCrossAppNavigator.isInitialNavigation() */ ) {
				history.back();
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#"
					}
				});
			}
		},

		/**
		 * Navigates to the previous entry in history or to the master screen which is associated with the
		 * currently displayed entity type. 'sTarget' is derived from a custom data property attached to the
		 * page control of the details view.
		 * @public
		 */
		navBackFromDetail: function(oEvent) {
			var sTarget = oEvent.getSource().data("parentView");

			var sDirection = History.getInstance().getDirection();

			if (sDirection === "Unknown") {
				this.getRouter().navTo(sTarget, {}, false);
			} else {
				history.back();
			}
		},

		/**
		 * Navigates after pressing a master list entry to 'ObjectsDetail' with the appropriate 'id' attached
		 * to the route and uri.
		 * @public
		 */
		navToTradeItem: function(oEvent) {
			var table = oEvent.getSource().getParent().getParent();
			table.setSelectedIndex(oEvent.getSource().getParent().getIndex());
			var oBindingContext = oEvent.getSource().getBindingContext();
			if (oBindingContext) {
				var oItemKey = oBindingContext.getProperty("EpcIdUri");
				if (oItemKey) {
					this.getOwnerComponent().getRouter().navTo("ObjectsDetail", {
						id: oItemKey,
						tab: "events"
					}, false);
				}
			}
		},

		/**
		 * Navigates after pressing a master list entry to 'LotsDetail' with the appropriate 'id' attached
		 * to the route and uri.
		 * @public
		 */
		navToLot: function(oEvent) {
			var table = oEvent.getSource().getParent().getParent();
			table.setSelectedIndex(oEvent.getSource().getParent().getIndex());
			var oBindingContext = oEvent.getSource().getBindingContext();
			if (oBindingContext) {
				var oItemKey = oBindingContext.getProperty("EpcClassUri");
				if (oItemKey) {
					this.getOwnerComponent().getRouter().navTo("LotsDetail", {
						id: oItemKey,
						tab: "events"
					}, false);
				}
			}
		},

		/**
		 * Navigates after pressing a master list entry to 'ContainersDetail' with the appropriate 'id' attached
		 * to the route and uri.
		 * @public
		 */
		navToContainer: function(oEvent) {
			var table = oEvent.getSource().getParent().getParent();
			table.setSelectedIndex(oEvent.getSource().getParent().getIndex());
			var oBindingContext = oEvent.getSource().getBindingContext();
			if (oBindingContext) {
				var oItemKey = oBindingContext.getProperty("EpcIdUri");
				if (oItemKey) {
					this.getOwnerComponent().getRouter().navTo("ContainersDetail", {
						id: oItemKey,
						tab: "events"
					}, false);
				}
			}
		},

		/**
		 * Navigates after pressing a master list entry to 'EventsDetail' with the appropriate 'id' attached
		 * to the route and uri.
		 * @public
		 */
		navToEvent: function(oEvent) {
			var table = oEvent.getSource().getParent().getParent();
			table.setSelectedIndex(oEvent.getSource().getParent().getIndex());
			var oBindingContext = oEvent.getSource().getBindingContext();
			if (oBindingContext) {
				var oItemKey = oBindingContext.getProperty("Evtid");
				if (oItemKey) {
					this.getOwnerComponent().getRouter().navTo("EventsDetail", {
						id: oItemKey,
						tab: "?"
					}, false);
				}
			}
		},

		/**
		 * Navigates after pressing a master list entry to 'RepeventsDetail' with the appropriate 'id' attached
		 * to the route and uri.
		 * @public
		 */
		navToRepEvent: function(oEvent) {
			var table = oEvent.getSource().getParent().getParent();
			table.setSelectedIndex(oEvent.getSource().getParent().getIndex());
			var oBindingContext = oEvent.getSource().getBindingContext();
			if (oBindingContext) {
				var oItemKey = oBindingContext.getProperty("RepEvtid");
				if (oItemKey) {
					this.getOwnerComponent().getRouter().navTo("RepeventsDetail", {
						id: oItemKey,
						tab: "?"
					}, false);
				}
			}
		},

		/**
		 * Navigates after pressing a master list entry to 'TransactionsDetail' with the appropriate 'id' attached
		 * to the route and uri.
		 * @public
		 */
		navToTransaction: function(oEvent) {
			var table = oEvent.getSource().getParent().getParent();
			table.setSelectedIndex(oEvent.getSource().getParent().getIndex());
			var oBindingContext = oEvent.getSource().getBindingContext();
			if (oBindingContext) {
				var oItemKey1 = oBindingContext.getProperty("Trncode");
				var oItemKey2 = oBindingContext.getProperty("Bizttype");
				if (oItemKey1 && oItemKey2) {
					this.getOwnerComponent().getRouter().navTo("TransactionsDetail", {
						id: oItemKey1 + "," + oItemKey2,
						tab: "events"
					}, false);
				}
			}
		},
		
		/**
		 * Navigates after pressing a master list entry to 'AuthrequestsDetail' with the appropriate 'id' attached
		 * to the route and uri.
		 * @public
		 */
		navToAuthRequest: function(oEvent) {
			var table = oEvent.getSource().getParent().getParent();
			table.setSelectedIndex(oEvent.getSource().getParent().getIndex());
			var oBindingContext = oEvent.getSource().getBindingContext();
			if (oBindingContext) {
				var oItemKey = oBindingContext.getProperty("Authid");
				if (oItemKey) {
					this.getOwnerComponent().getRouter().navTo("AuthrequestsDetail", {
						id: oItemKey,
						tab: "relatedObjects"
					}, false);
				}
			}
		},

		/**
		 * Navigates after pressing on the link displaying the 'Lotno' in the Details header of a Object Item to
		 * 'LotsDetail'.
		 * @public
		 */
		navFromObjectToLot: function() {
			var sLotId = this.getView().getModel().getProperty(this.getView().getBindingContext().getPath() + "/Lot/EpcClassUri");
			this.getOwnerComponent().getRouter().navTo("LotsDetail", {
				id: sLotId,
				tab: "events"
			}, false);
		},

		/**
		 * Navigates after pressing a list entry in the related objects tab of the Lot Details to 'ObjectsDetail'. 
		 * @public
		 */
		navByGs1: function(oEvent) {
			this.getView().byId("LotObjItmTable").setSelectedIndex(oEvent.getSource().getParent().getIndex());
			var oBindingContext = oEvent.getSource().getBindingContext();
			if (oBindingContext) {
				var oItemKey = oBindingContext.getProperty("EpcIdUri");
				if (oItemKey) {
					this.getOwnerComponent().getRouter().navTo("ObjectsDetail", {
						id: oItemKey,
						tab: "events"
					}, false);
				}
			}
		},

		/**
		 * Navigates after pressing the action button of a list entry in the transaction list in the related tab of
		 * a Details screen.
		 * @public
		 */
		navToTransactionByButton: function(oEvent) {
			var sTarget = "TransactionsDetail";
			var sTrnCode = this.getModel().getProperty(oEvent.getSource().getBindingContext().getPath() + "/Trncode");
			var sBizttype = this.getModel().getProperty(oEvent.getSource().getBindingContext().getPath() + "/Bizttype");
			this.getOwnerComponent().getRouter().navTo(sTarget, {
				id: sTrnCode + "," + sBizttype
			}, false);
		},

		/**
		 * Navigates after pressing the action button of a list entry's detail in the event tab of
		 * a Details screen.
		 * @public
		 */
		navToEventByButton: function(oEvent) {
			var sTarget = "EventsDetail";
			var sEvtid = this.getModel().getProperty(oEvent.getSource().getBindingContext().getPath() + "/Evtid");
			this.getOwnerComponent().getRouter().navTo(sTarget, {
				id: sEvtid
			}, false);
		},

		/**
		 * Navigates after pressing the action button of a list entry's detail in the reporting event tab of
		 * a Details screen.
		 * @public
		 */
		navToRepEventByButton: function(oEvent) {
			var sTarget = "RepeventsDetail";
			var sRepEvtid = this.getModel().getProperty(oEvent.getSource().getBindingContext().getPath() + "/RepEvtid");
			this.getOwnerComponent().getRouter().navTo(sTarget, {
				id: sRepEvtid
			}, false);
		},

		/**
		 * Navigates after pressing a list entry of a generic objects list depending on the type of the reffered object.
		 * For example this is used for navigating from the entries in the hiearchy tables.
		 * @public
		 */
		navToObjectByType: function(oEvent) {
			var sTarget = "";
			var sKey = oEvent.getSource().getText();
			var oModel = this.getModel("hry") || this.getModel();
			var oContext = oEvent.getSource().getBindingContext("hry") || oEvent.getSource().getBindingContext();
			var oObject = oContext.getObject();
			var sType = oObject.ObjType || oObject.Objtype || oObject.t;
			var bValid = true;

			switch (parseInt(sType,10)) {
				case 1:
					sTarget = "LotsDetail";
					break;
				case 2:
					sTarget = "ObjectsDetail";
					break;
				case 3:
					sTarget = "ContainersDetail";
					break;
				default:
					sTarget = "";
					bValid = false;
			}

			if (bValid) {
				this.getOwnerComponent().getRouter().navTo(sTarget, {
					id: sKey
				}, false);
			}
		},

		navToHistHierarchy: function(oEvent) {
			var sTarget = "HistHierarchy";
			var sObjid = this.getModel().getProperty(this.getView().getBindingContext().getPath() + "/EpcIdUri");
			var sTimestamp = this.getView().getModel().getProperty(oEvent.getSource().getBindingContext().getPath() + "/EvttimeExact");
			this.getOwnerComponent().getRouter().navTo(sTarget, {
				id: sObjid + "," + sTimestamp.trim()
			}, false);
		}
	};
}, true);