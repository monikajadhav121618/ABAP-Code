/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define(["sap/ui/table/TablePersoController"], function(TablePersoController) {
	"use strict";

	/**
	 * Delegate for performing actions which are related to personalization and variant management that are
	 * shared among different screens. Personalization is done via the Containers supplied by the surrounding
	 * Fiori launchpad implementation.
	 *
	 * @name com.sap.cd.sttp.zcockpit.delegate.shared.PersonalizationDelegate
	 */
	return {
		mMap: {},

		/**
		 * This function is used in the 'onInit' of master controllers. It initialises the built-in VariantManagement of
		 * the FilterBar control and adds the functionality that also the actual values which are put into the filter items
		 * are stored.
		 * 
		 * @param {string}
		 *            sView name of the invoking view control
		 * @param {object}
		 *            oView the invoking view control
		 * @public
		 */
		initVariantManagementForView: function(sView, oView) {

			var oFBar = oView.byId("filterbar");
			var oVM = null;
			
			if (oFBar.getVariantManagement) {
				// SAPUI5 v1.40+
				oVM = oFBar.getVariantManagement();	
				oVM._delayedControlCreation();
			} else {
				oVM = oFBar._oVariantManagement;
			}
			
			if (oVM._createSaveDialog) {
				// SAPUI5 v1.38+
				oVM._createSaveDialog();
			};

			oVM.oSaveDialog.attachAfterOpen(function(oEvent) {
				var aVariantItems = oVM.getVariantItems();
				var oBeginButton = oEvent.getSource().getBeginButton();
				oBeginButton.setEnabled(false);
				var oInput = oEvent.getSource().getContent()[1];
				oInput.attachLiveChange(function(oChangeEvent) {
					var bIsDuplicate = false;
					for (var i = 0, len = aVariantItems.length; i < len; i++) {
						var el = aVariantItems[i];
						if (el.getText() === oChangeEvent.getParameter("value")) {
							bIsDuplicate = true;
							break;
						} else {
							bIsDuplicate = false;
						}
					}
					oBeginButton.setEnabled(!bIsDuplicate);
				});
			});
			var reactOnInputChange = function() {
				oVM.currentVariantSetModified(true);
			};

			oFBar.registerFetchData(function() {
				var aFilterItems = this.getFilterItems();
				var mData = {};
				for (var i in aFilterItems) {
					var oControl = this.determineControlByName(aFilterItems[i].getName());
					var oData = {};

					if (oControl instanceof sap.m.Input) {
						oControl.attachLiveChange(reactOnInputChange);
						oData = { value: oControl.getValue() };

					} else if (oControl instanceof sap.m.DateTimeInput) {
						oControl.attachChange(reactOnInputChange);
						oData = { value: oControl.getValue() };

					} else if (oControl instanceof sap.m.Select) {
						oControl.attachChange(reactOnInputChange);
						oData = { selectedKey: oControl.getSelectedKey() };

					} else if (oControl instanceof sap.m.CheckBox) {
						oControl.attachSelect(reactOnInputChange);
						oData = { selected: oControl.getSelected() };
					}

					mData[aFilterItems[i].getName()] = oData;
				}
				return mData;
			});

			oFBar.registerApplyData(function(mData) {
				for (var name in mData) {
					var oControl = this.determineControlByName(name);

					if (oControl instanceof sap.m.Input) {
						oControl.setValue(mData[name].value);

					} else if (oControl instanceof sap.m.DateTimeInput) {
						oControl.setValue(mData[name].value);

					} else if (oControl instanceof sap.m.Select) {
						oControl.setSelectedKey(mData[name].selectedKey);

					} else if (oControl instanceof sap.m.CheckBox) {
						oControl.setSelected(mData[name].selected);
					}
				}
			});

			oVM.initialise();
		},

		/**
		 * This function is used in the 'onInit' of master controllers. It initialises a TablePersoController for storing
		 * personalization infos of the master tables and also registers a handler for the personalization settings button.
		 * 
		 * @param {string}
		 *            sView name of the invoking view control
		 * @param {object}
		 *            oView the invoking view control
		 * @public
		 */
		initTablePersonalizationForView: function(sView, oView) {
			if (sap.ushell && sap.ushell.Container) {
				var oPersId = {
					container: sView,
					item: "table"
				};
				var oProvider = sap.ushell.Container.getService("Personalization").getPersonalizer(oPersId);
				var oTablePersoController = new TablePersoController({
					table: oView.byId("masterTable"),
					persoService: oProvider
				});
				oView.byId("persButton").attachPress(function(oEvent) {
					oTablePersoController.openDialog();
				});
			}
		},

		initTablePersonalizationForTable: function(sKey, oTable, oButton, bSkipPers, iOffset) {
			if (!bSkipPers && sap.ushell && sap.ushell.Container) {
				var oPersId = {
					container: sKey,
					item: "table"
				};
				var oProvider = sap.ushell.Container.getService("Personalization").getPersonalizer(oPersId);
				var oTablePersoController = new TablePersoController({
					table: oTable,
					persoService: oProvider
				});

				if (oButton) {
					oButton.attachPress(function(oEvent) {
						oTablePersoController.openDialog();
					});
				}
			}
		}
	};
}, true);