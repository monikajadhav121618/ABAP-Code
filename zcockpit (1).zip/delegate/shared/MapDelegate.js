/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define([], function() {
	"use strict";

	/**
	 * Delegate for performing actions which are related to personalization and variant management that are
	 * shared among different screens. Personalization is done via the Containers supplied by the surrounding
	 * Fiori launchpad implementation.
	 *
	 * @name com.sap.cd.sttp.zcockpit.delegate.shared.MapDelegate
	 */
	return {
    /**
		 * Initialises the map control and tries to fetch the customization data for the Map provider URIs from the
		 * backend function import /GetMapProvider. The URI must be in a certain format which is explained in the
		 * API for the GeoMap control. Upon retrieval of the URIs the map can be displayed accordingly.
		 * @private
		 */
	  initMap: function() {
			var that = this;
			var _fnSuccess = function(oData) {
				var oMap = that.getView().byId("theMap");
				var oNoMap = that.getView().byId("noMapText");
				if (oData && oData.TextValue) {
					try {
						var aUris = oData.TextValue.split("###");
						var aSource = aUris.map(function(sUri, iIndex) {
							return {
								id: iIndex,
								url: sUri
							};
						});
						var oMapConfig = {
							"MapProvider": [{
								"name": "Custom",
								"type": "",
								"description": "",
								"tileX": "256",
								"tileY": "256",
								"maxLOD": "20",
								"copyright": "",
								"Source": aSource
							}],
							"MapLayerStacks": [{
								"name": "Default",
								"MapLayer": {
									"name": "layer1",
									"refMapProvider": "Custom",
									"opacity": "1.0",
									"colBkgnd": "RGB(255,255,255)"
								}
							}]
						};
						oMap.setMapConfiguration(oMapConfig);
					} catch (oException) {
						// error parsing mapprovider uris
						oMap.setVisible(false);
						oNoMap.setVisible(true);
						return;
					}
				} else {
					// no mapprovider uris found
					oMap.setVisible(false);
					oNoMap.setVisible(true);
					return;
				}
			};

			this.getOwnerComponent().getModel().read("/GetMapProvider", {
				success: _fnSuccess
					/*,
									error: _fnError*/
			});
    }
  };
}, true);