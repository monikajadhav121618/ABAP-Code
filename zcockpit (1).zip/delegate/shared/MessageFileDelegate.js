/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define([
	"com/sap/cd/sttp/zcockpit/delegate/shared/MessageFilesDialogDelegate",
	"sap/ui/core/message/Message"
], function (MessageFilesDialogDelegate, Message) {
	"use strict";

	/**
	 * Delegate for requesting documents (message files) in different formats from the backend, and
	 * exposing them to the user by using browser-specific implementations. This delegate is supplemented
	 * by the MessageFilesDialogDelegate.
	 *
	 * @name com.sap.cd.sttp.zcockpit.delegate.shared.MessageFileDelegate
	 */
	return {
		/**
		 * This is called when the user requests the message file(s) from a reporting event. From the 
		 * object binding the 'MsguidOut' is taken and sent to the '/GetRawMessage' Function import of 
		 * the backend service. The response is expected to be a list of all available messages independent
		 * of which format the files are (XML,CSV). Afterwards a dialog is opened to show a list of available
		 * messages to the user.
		 * @public
		 */
		onShowMessageFilePress: function (oEvent) {
			var that = this;
			var sId = "'" + this.getModel().getProperty(oEvent.getSource().getBindingContext().getPath() + "/MsguidOut") + "'";
			var _fnError = function () {
				return;
			};

			that.getView().getModel().read("/GetRawMessage", {
				urlParameters: {
					"Id": sId,
					"Switch": "'01'"
				},
				success: function (oData) {
					var _fnGetMessageFilesDialogDelegate = function () {
						if (!that._oMessageFilesDialogDelegate) {
							that._oMessageFilesDialogDelegate = new MessageFilesDialogDelegate();
							var oFragment = that._oMessageFilesDialogDelegate.getFragment();
							that.getView().addDependent(oFragment);
						}
						return that._oMessageFilesDialogDelegate;
					};

					var dialog = _fnGetMessageFilesDialogDelegate();
					dialog.open(oData);
				},
				error: _fnError
			});
		},

		/**
		 * This is called when the user requests an EPCIS message file. From the object binding the 'MsguidIn' is
		 * taken and sent to the '/GetRawMessage' Function import of the backend service ('Switch' = '02'). The 
		 * response is expected to be a list of exactly one message in XML format. A browser-specific implementation
		 * is then invoked to either display (Google Chrome) or download (Internet Explorer) the XML file.
		 * @public
		 */
		onShowEPCISMessageFilePress: function (oEvent) {
			var that = this;
			var oEventObject = oEvent.getSource().getBindingContext().getObject();

			if (oEventObject.AutoEvent === 'X') {
				var oMessageManager = sap.ui.getCore().getMessageManager();
				oMessageManager.addMessages(
					new Message({
						message: this.getModel("i18n").getProperty("MSGFILE_AUTO_EVENT"),
						type: sap.ui.core.MessageType.Error,
						processor: this.getModel()
					})
				);
				this.getView().byId("btnToggleMsgs").firePress();
			} else {
				this.getView().getModel().read("/GetRawMessage", {
					urlParameters: {
						"Id": "'" + oEventObject.MsguidIn + "'",
						"Switch": "'02'"
					},
					success: function (oData) {
						if (oData && oData.results && oData.results.length > 0 && oData.results[0].TextValue) {
							var uriContent = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" + oData.results[0].TextValue;
							var oBlob = new Blob([uriContent], {
								type: "application/xml"
							});
							if (window.navigator.msSaveOrOpenBlob) { // if InternetExplorer
								window.navigator.msSaveOrOpenBlob(oBlob, "epcis.xml");
							} else {
								var newWin = window.open(window.URL.createObjectURL(oBlob));
								if (!newWin || newWin.closed || typeof newWin.closed == 'undefined') {
									alert(that.getView().getModel("i18n").getProperty("DISABLE_POPUP_BLOCKER"));
								}
							}
						}
					}
				});
			}

		}
	};
}, true);