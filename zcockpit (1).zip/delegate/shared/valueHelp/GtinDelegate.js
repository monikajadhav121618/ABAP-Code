/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define([
	"com/sap/cd/sttp/zcockpit/delegate/BaseDelegate"
], function(BaseDelegate) {
	"use strict";

	/**
	 * Delegate for handling actions of the Gtin value help dialog, which is two-parted: Search by GTIN and
	 * search by Material number.
	 *
	 * @name com.sap.cd.sttp.zcockpit.delegate.shared.valueHelp.GtinDelegate
	 */
	return BaseDelegate.extend("com.sap.cd.sttp.zcockpit.delegate.shared.valueHelp.GtinDelegate", {
		_sFragmentName: "com.sap.cd.sttp.zcockpit.fragment.shared.valueHelp.Gtin",

		/**
		 * Opens the dialog.
		 * @public
		 */
		open: function(oSourceInputControl)  {
		    this._oSourceInputControl = oSourceInputControl;
			this.byId("GtinDialog").open();
		},


		/**
		 * Cancels and closes the dialog.
		 * @public
		 */
		handleDialogCancelPressed: function() {
			this.byId("GtinDialog").close();
		},

		/**
		 * Handler for pressing the search button in the GTIN tab. Filters the list of GTINs by GTIN and description.
		 * @public
		 */
		handleSearch: function(oEvent) {
			var sValue = oEvent.getParameter("query");
			var oFilter = new sap.ui.model.Filter("Gtin", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter2 = new sap.ui.model.Filter("Text", sap.ui.model.FilterOperator.Contains, sValue);
			var oBinding = this.byId("GtinDialogList").getBinding("items");
			oBinding.filter(new sap.ui.model.Filter([oFilter, oFilter2], false));
			var oSorter = new sap.ui.model.Sorter("Gtin", false);
			oBinding.sort(oSorter);
		},

		/**
		 * Handler for pressing the Go button in the Material tab. Filters the list of GTINs by 'MatnrExt' and 'LogQS'.
		 * @public
		 */
		handleGoPressed: function() {
			var sValueMatno = this.byId("InputMatNo").getValue();
			var sValueLogSysGrp = this.byId("InputLogSysGrp").getValue();
			var oFilter = new sap.ui.model.Filter("MatnrExt", sap.ui.model.FilterOperator.Contains, sValueMatno);
			var oFilter2 = new sap.ui.model.Filter("LogQS", sap.ui.model.FilterOperator.Contains, sValueLogSysGrp);
			var oBinding = this.byId("GtinDialogMatList").getBinding("items");
			oBinding.filter(new sap.ui.model.Filter([oFilter, oFilter2], true));
			var oSorter = new sap.ui.model.Sorter("Gtin", false);
			oBinding.sort(oSorter);
		},

		/**
		 * Handler for pressing the Clear button in the Material tab.
		 * @public
		 */
		handleClearPressed: function() {
			this.byId("InputMatNo").setValue("");
			this.byId("InputLogSysGrp").setValue("");
			var oBinding = this.byId("GtinDialogMatList").getBinding("items");
			oBinding.filter(null);
		},


		/**
		 * Handler for pressing a list item in the GTIN tab.
		 * @public
		 */
		handleItemPressed: function(oEvent) {
            this._oSourceInputControl.setValue(oEvent.getParameter("listItem").getTitle());
            this.byId("GtinDialog").close();
		},
		
		/**
		 * Handler for pressing a list item in the Material tab.
		 * @public
		 */
		handleCustomItemPressed: function (oEvent) {
		    var sGtin = oEvent.getParameter("listItem").getBindingContext().getObject().Gtin;
		    this._oSourceInputControl.setValue(sGtin);
		    this.byId("GtinDialog").close();
		}
	});
});