/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define([
	"com/sap/cd/sttp/zcockpit/delegate/BaseDelegate",
	"sap/ui/model/json/JSONModel"
], function(BaseDelegate, JSONModel) {
	"use strict";

	/**
	 * Delegate for handling actions concerning the Message file dialog. This dialog gives a list of
	 * items to the user from which he can download the available message files of a reporting event.
	 * Browser-specific implementations are involved.
	 *
	 * @name com.sap.cd.sttp.zcockpit.delegate.shared.MessageFilesDialogDelegate
	 */
	return BaseDelegate.extend("com.sap.cd.sttp.zcockpit.delegate.shared.MessageFilesDialogDelegate", {
		_sFragmentName: "com.sap.cd.sttp.zcockpit.fragment.shared.detail.reportingEvents.MessageFilesDialog",

		/**
		 * Opens the dialog and sets data to a model which is passed from an outside caller.
		 * 
		 * @param {object}
	 	 *            oData an object containing an array of results which can be binded
		 * @public
		 */
		open: function(oData) {
			this.byId("msgFilesDialog").open();
			var oModel = new JSONModel({ results : oData.results });
			this.byId("msgFilesDialog").setModel(oModel, "dialogModel");
		},
		

		/**
		 * Closes the dialog.
		 * @public
		 */
		cancel: function() {
			this.byId("msgFilesDialog").close();
		},
		
		
		/**
		 * Handler for pressing an list item in the message files list. Subsequent action depends on the file type
		 * which is derived from the 'Id' property of the backend data (Has to be somehow set in the backend). In case
		 * of a XML file type an additional starting tag is added. Afterwards the browser-specific actions are taken to
		 * either display (Google Chrome) or download (Internet Explorer) the files.
		 * 
		 * @public
		 */
		itemPress : function(oEvent) {
			var oObject = oEvent.getParameter("listItem").getBindingContext("dialogModel").getObject(),
				sId = oObject.Id,
				uriContent,
				oBlob;
			
			if (sId.indexOf("XML") >= 0) {
				uriContent = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" + oObject.TextValue;
				oBlob = new Blob([uriContent], { type: "application/xml" });
				if (window.navigator.msSaveOrOpenBlob) { // if InternetExplorer
					window.navigator.msSaveOrOpenBlob(oBlob, sId + ".xml");
				} else {
					window.open(window.URL.createObjectURL(oBlob));
				}
			} else {
				uriContent = oObject.TextValue;
				oBlob = new Blob([uriContent], { type: "text/plain" });
				if (window.navigator.msSaveOrOpenBlob) { // if InternetExplorer
					window.navigator.msSaveOrOpenBlob(oBlob, sId + ".csv");
				} else {
					var newWin = window.open(window.URL.createObjectURL(oBlob));
					if(!newWin || newWin.closed || typeof newWin.closed=='undefined') 
					{ 
						alert(that.getView().getModel("i18n").getProperty("DISABLE_POPUP_BLOCKER"));
					}
				}
			}
		} 
	});
});