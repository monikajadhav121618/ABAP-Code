/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define([], function () {
	"use strict";

	/**
	 * Delegate for handling actions which are shared among all details screens.
	 *
	 * @name com.sap.cd.sttp.zcockpit.delegate.shared.DetailsDelegate
	 */
	return {

		toggleHeader: function (oEvent) {
			var oPageLayout = this.getView().byId("pageLayout");
			oPageLayout.setShowHeaderContent(!oPageLayout.getShowHeaderContent());

			// extra logic for Safari
			if (/ipad|iphone|ipod/i.test(navigator.userAgent.toLowerCase())) {
				if (oPageLayout.getShowHeaderContent()) {
					oPageLayout.setHeight((window.innerHeight - 80) + "px");
				} else {
					oPageLayout.setHeight(window.innerHeight + "100%");
				}
			}
		},

		/**
		 * Called whenever a tab of the IconTabBar is selected. Depending on the 'key' property of the tab it
		 * might be necessary to request additional data from the backend.
		 * @public
		 */
		onSelectChanged: function (oEvent) {
			var key = oEvent.getParameters().key;
			switch (key) {
				case 'relatedObjects':
					this.loadRelatedObjects();
					break;
				case 'relatedItemsCompare':
					this.loadRelatedItemsComp();
					break;
				case 'hierarchy':
					this.loadHierarchy();
					break;
				case 'authRequests':
					this.loadAuthRequests();
					break;
				case 'relatedTradeItems':
					this.loadLotObjItms();
					break;
				case 'eventsMap':
					this.loadEventLocationData();
					break;
				default:
					// Call controller's custom extension hook.
					this.extHook_onTabChanged(key);
					return;
			}
		},

		/**
		 * Called after a new list of events has been received from the backend. Since the backend does not sort
		 * the entries of the list, this has to be done locally. The sorter implementation considers UTC time
		 * and the provided UTC Offset to get the chronological order of events. If the list is not empty the
		 * first item of the list is selected and displayed in the details section of the tab.
		 * @public
		 */
		onEventsLoaded: function (oEvent) {
			if (oEvent.getParameter("total") > 0) {
				var oFirstItem = oEvent.getSource().getItems()[0];
				oEvent.getSource().fireItemPress({
					listItem: oFirstItem,
					srcControl: oEvent.getSource()
				});
				this.getView().byId("eventDetailsForm").setVisible(true);
			} else {
				this.getView().byId("eventDetailsForm").setVisible(false);
			}
		},

		/**
		 * Called after a new list of transactions has been received from the backend. If the list is not empty
		 * the first item of the list is selected and displayed in the details section of the tab.
		 * @public
		 */
		onTransactionsLoaded: function (oEvent) {
			if (oEvent.getParameter("total") > 0) {
				var oFirstItem = oEvent.getSource().getItems()[0];
				oEvent.getSource().fireItemPress({
					listItem: oFirstItem,
					srcControl: oEvent.getSource()
				});
				this.getView().byId("transactionDetailsForm").setVisible(true);
			} else {
				this.getView().byId("transactionDetailsForm").setVisible(false);
			}
		},

		/**
		 * Called after a new list of reporting events has been received from the backend. Since the backend 
		 * does not sort the entries of the list, this has to be done locally. The sorter implementation considers 
		 * the 'CreationTime' property to get the chronological order of reporting events. If the list is not 
		 * empty the first item of the list is selected and displayed in the details section of the tab.
		 * @public
		 */
		onRepEventsLoaded: function (oEvent) {
			// resort events by Evttime (maybe offset has to be considered?)
			var oTable = oEvent.getSource();
			var aItems = oEvent.getSource().getItems();
			aItems.sort(function (a, b) {
				if (a.getBindingContext().getProperty("CreationTime") > b.getBindingContext().getProperty("CreationTime")) {
					return 1;
				}
				if (a.getBindingContext().getProperty("CreationTime") < b.getBindingContext().getProperty("CreationTime")) {
					return -1;
				}
				// a must be equal to b
				return 0;
			});
			oTable.removeAllItems();

			$.each(aItems, function (oIndex, oItem) {
				oTable.addItem(oItem);
			});
			// end of resort

			if (oEvent.getParameter("total") > 0) {
				var oFirstItem = oEvent.getSource().getItems()[0];
				oEvent.getSource().fireItemPress({
					listItem: oFirstItem,
					srcControl: oEvent.getSource()
				});
				this.getView().byId("repEventDetailsForm").setVisible(true);
			} else {
				this.getView().byId("repEventDetailsForm").setVisible(false);
			}
		},

		/**
		 * Requests a string from the /GetHierarchyPath backend function import. This string carries information on how
		 * to locate the 'currentObjectId' inside a hierarchy of objects. The actual highlighting of the path is done by
		 * a formatter. For details see the formatter implementation in com.sap.cd.sttp.zcockpit.model.formatter.GeneralFormatter.LocateObject.
		 * @public
		 */
		locateObject: function () {
			var that = this;
			this.getView().getModel().read("/GetHierarchyPath", {
				urlParameters: {
					"Objid": "'" + this.sCurrentId + "'"
				},
				success: function (oData) {
					if (oData && oData.TextValue) {
						that.getOwnerComponent().getModel("settings").setProperty("/HierarchyPath", oData.TextValue);
					}
				}
			});
		},

		/**
		 * Handler for pressing an item of the events list. Highlights the current selection and updates the
		 * details section of the tab content.
		 * @public
		 */
		handleEventPressed: function (oEvent) {
			var oItem = oEvent.mParameters.listItem;

			if (this._currentEventItem) {
				this._currentEventItem.setUnread(false);
				this._currentEventItem.setType("Active");
			}

			oItem.setUnread(true);
			oItem.setType("Navigation");
			this._currentEventItem = oItem;

			this.getView().byId("eventDetailsForm").bindObject(oItem.getBindingContextPath());
		},

		/**
		 * Handler for pressing an item of the transactions list. Highlights the current selection and updates the
		 * details section of the tab content.
		 * @public
		 */
		handleTransactionPressed: function (oEvent) {
			var oItem = oEvent.mParameters.listItem;

			if (this._currentTrnItem) {
				this._currentTrnItem.setUnread(false);
				this._currentTrnItem.setType("Active");
			}

			oItem.setUnread(true);
			oItem.setType("Navigation");
			this._currentTrnItem = oItem;

			this.getView().byId("transactionDetailsForm").bindObject(oItem.getBindingContextPath());
		},

		/**
		 * Handler for pressing an item of the rep. events list. Highlights the current selection and updates the
		 * details section of the tab content.
		 * @public
		 */
		handleRepEventPressed: function (oEvent) {
			var oItem = oEvent.mParameters.listItem;

			if (this._currentRepEventItem) {
				this._currentRepEventItem.setUnread(false);
				this._currentRepEventItem.setType("Active");
			}

			oItem.setUnread(true);
			oItem.setType("Navigation");
			this._currentRepEventItem = oItem;

			this.getView().byId("repEventDetailsForm").bindObject(oItem.getBindingContextPath());
		}
	};
}, true);