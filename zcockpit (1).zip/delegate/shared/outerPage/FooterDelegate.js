/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define([
	"sap/m/MessagePopover",
	"sap/m/MessagePopoverItem",
	"sap/m/MessageBox",
	"com/sap/cd/sttp/zcockpit/util/BackendHelper"
], function (MessagePopover, MessagePopoverItem, MessageBox, BackendHelper) {
	"use strict";

	var _messagePopover = null;
	var _oMenuActionSheet = null;
	var _oHistoryDialog = null;
	var _oSearchDialog = null;

	/**
	 * Delegate for handling actions related to the footer UI area that is always shown on all pages of the application.
	 * The footer is composed of a Message popover, a History dialog, a Search dialog and the main Menu navigation.
	 * The involved UI definitions can be found at com.sap.cd.sttp.zcockpit.fragment.shared.outerPage.*
	 *
	 * @name com.sap.cd.sttp.zcockpit.delegate.shared.outerPage.FooterDelegate
	 */
	return {

		/**
		 * Handler for pressing the Messages button in the footer. Displays/hides the popover containing all messages.
		 * @public
		 */
		handleMessagePopoverPressed: function (oEvent) {
			var oMessagesButton = oEvent.getSource();
			if (!_messagePopover) {
				_messagePopover = new MessagePopover({
					items: {
						path: "messages>/",
						template: new MessagePopoverItem({
							description: "{messages>description}",
							type: "{messages>type}",
							title: "{messages>message}"
						})
					}
				});
				_messagePopover.setModel(this.getModel("messages"), "messages");
			}
			_messagePopover.toggle(oMessagesButton);
		},

		/**
		 * Handler for pressing the Menu button in the footer. Displays/hides a Selection popover containing a number of
		 * items to navigate between the different master screens. Based on its fragment.
		 * @public
		 */
		handleFooterMenuPressed: function (oEvent) {
			var oButton = oEvent.getSource();
			// create action sheet only once
			if (!_oMenuActionSheet) {
				_oMenuActionSheet = sap.ui.xmlfragment("com.sap.cd.sttp.zcockpit.fragment.shared.outerPage.Navigation", this);
				_oMenuActionSheet.setModel(this.getModel("i18n"), "i18n");
			}
			_oMenuActionSheet.openBy(oButton);
		},

		/**
		 * Handler for pressing a Menu item from the Menu selection dialog. The appropriate navigation targets are
		 * obtained from a hard-coded ID in the UI definition of the control.
		 * @public
		 */
		handleFooterMenuItemPressed: function (oEvent) {
			var oCurrentItem = oEvent.getSource();
			var sTarget = oCurrentItem.getId();
			sap.ui.getCore().getOwnerComponent().getRouter().navTo(sTarget, {}, false);
		},

		/**
		 * Handler for pressing the History button in the footer. Displays the history dialog based on its fragment.
		 * @public
		 */
		handleFooterHistoryPressed: function (oEvent) {
			if (!_oHistoryDialog) {
				_oHistoryDialog = sap.ui.xmlfragment("com.sap.cd.sttp.zcockpit.fragment.shared.outerPage.History", this);
				_oHistoryDialog.addStyleClass("sapUiSizeCompact");
				_oHistoryDialog.setModel(this.getModel("routing"), "routing");
				_oHistoryDialog.setModel(this.getModel("i18n"), "i18n");
			}
			_oHistoryDialog.open();
		},

		/**
		 * Handler for pressing the Search button in the footer. Displays the search dialog based on its fragment.
		 * @public
		 */
		handleFooterSearchPressed: function (oEvent) {
			if (!_oSearchDialog) {
				_oSearchDialog = sap.ui.xmlfragment("com.sap.cd.sttp.zcockpit.fragment.shared.outerPage.Search", this);
				_oSearchDialog.attachAfterOpen(function (oEv) {
					oEv.getSource().$().bind("keyup", $.proxy(function (e) {
						var code = e.which;
						if (code === 27) { // ESCAPE
							e.preventDefault();
							_oSearchDialog.close();
						}
					}));
				});
				_oSearchDialog.setModel(this.getModel("i18n"), "i18n");
			}
			_oSearchDialog.open();
		},

		/**
		 * Handler for pressing the close/cancel button in the search dialog.
		 * @public
		 */
		handleCloseSearchDialog: function (oEvent) {
			_oSearchDialog.getSubHeader().getContent()[0].setValue("");
			_oSearchDialog.close();
		},

		/**
		 * Handler for pressing the search button in the search dialog. Since the application does not know which kind
		 * of entity has to be retrieved from the character string inputted by the user, first a backend request to 
		 * /ObjTypeSet is invoked to determine the type ('I' = ObjItem, 'L' = Lot, 'C' = Container, 'T' = Transaction).
		 * Depending on the determined type a Navigation to the appropriate details screens is invoked. There is an
		 * exception for Transaction codes since these are only unique in conjunction with a Bizttype. Therefore in this
		 * case a navigation to the master screen is invoked.
		 * @public
		 */
		handleGlobalSearchInvoked: function (oEvent) {
			var oSource = oEvent.getSource();
			var sCode = oSource instanceof sap.m.SearchField ? oEvent.getParameter("query") : oSource.getText();
			var that = this;
			if (!!sCode) {
				BackendHelper.getInferredRoute(sCode)
					.then(function (oResult) {
						if (oResult.type === "T") {
							sap.ui.core.routing.HashChanger.getInstance().replaceHash("transactions");
						}
						sap.ui.getCore().getOwnerComponent().getRouter().navTo(oResult.route, oResult.routeParam, false);
						if (_oSearchDialog) {
							if (oSource instanceof sap.m.SearchField) oSource.setValue("");
							_oSearchDialog.close();
						}
					}).catch(function (oError) {
						if (oError && oError.statusCode === "404") {
							MessageBox.show(that.getView().getModel("i18n").getProperty("SEARCH_NOT_FOUND_WARNING"), {
								icon: MessageBox.Icon.WARNING,
								title: that.getView().getModel("i18n").getProperty("WARNING")
							});
						} else {
							MessageBox.show(that.getView().getModel("i18n").getProperty("SEARCH_INVALID_INPUT_MSG"), {
								icon: MessageBox.Icon.WARNING,
								title: that.getView().getModel("i18n").getProperty("WARNING")
							});
						}
					});
			}
		},

		/**
		 * Handler for performing a search in the history dialog. Search filters over the properties 'name' OR 'id'.
		 * @public
		 */
		handleSearchHistoryDialog: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new sap.ui.model.Filter("name", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter2 = new sap.ui.model.Filter("arguments/id", sap.ui.model.FilterOperator.Contains, sValue);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter(new sap.ui.model.Filter([oFilter, oFilter2], false));
		},

		/**
		 * Handler for pressing an list item in the history dialog. A navigation to the selected Page (Master or Details)
		 * is invoked. In the case of Details pages the property 'id' of the route's argument is set from the description
		 * property of the selected list item.
		 * @public
		 */
		handleConfirmHistoryDialog: function (oEvent) {
			var oCurrentListItem = oEvent.getParameter("selectedItem");
			var oArguments = {
				id: oCurrentListItem.getDescription()
			};
			var sTarget = oCurrentListItem.getBindingContext("routing").getObject().name;
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter(null);
			sap.ui.getCore().getOwnerComponent().getRouter().navTo(sTarget, oArguments, false);
		}
	};
}, true);