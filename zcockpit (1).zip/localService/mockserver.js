/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define([
    "sap/ui/core/util/MockServer"
], function (MockServer) {
    "use strict";

    return {
        /**
         * Initializes the mock server. You can configure the delay with the URL parameter "serverDelay"
         * The local mock data in this folder is returned instead of the real data for testing.
         *
         * @public
         */
        init: function () {
            var oUriParameters = jQuery.sap.getUriParameters(),
                oMockServer = new MockServer({
                    rootUri: "/sap/opu/odata/sttp/ATT_COCKPIT_210_SRV/"
                }),
                sPath = jQuery.sap.getModulePath("com.sap.cd.sttp.zcockpit.localService");
           
            // configure mock server with a delay of 1s
            MockServer.config({
                autoRespond: true,
                autoRespondAfter: (oUriParameters.get("serverDelay") || 500)
            });

            // load local mock data
            oMockServer.simulate(sPath + "/metadata.xml", {
                sMockdataBaseUrl: sPath + "/mockdata",
                bGenerateMissingMockData: true
            });

            oMockServer.start();
            this.oMockServer = oMockServer;

            jQuery.sap.log.info("Running the app with mock data");
        },

        /**
         * @public returns the mockserver of the app, should be used in integration tests
         * @returns {sap.ui.core.util.MockServer} the mockserver instance
         */
        getMockServer: function () {
            return this.oMockServer;
        }
    };
});