/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define([], function () {
    "use strict";

    /**
     * Gets a fixed Value from the FixedValue Model
     *
     * @param {string}
     * 				sType the name of the fixed value set
     * @param {string}
     * 				sValue the given value for which the actual item from the FixedValue set should be returned
     * @returns {string} the mapped value from the FixedValue set
     * @public
     */
    var getFixedValue = function (sType, sValue) {
        sValue = "" + sValue; //awkward but necessary string conversion
        var oFixedValueModel = sap.ui.getCore().getOwnerComponent().getModel("fixedValuesMD");
        var aValues = oFixedValueModel.getProperty("/FixedValueSet/" + sType);
        if (aValues) {
            for (var i = 0; i < aValues.length; i++) {
                if (aValues[i].Valpos && aValues[i].Domvalue_l === sValue) {
                    //return sValue + " - " + aValues[i].Ddtext;
                    return aValues[i].Ddtext;
                }
            }
        }
        return sValue;
    };

    /**
     * Collection of formatters which are accessing the FixedValues Model
     *
     * @name com.sap.cd.sttp.zcockpit.model.formatter.FixedValueFormatter
     */
    return {
        FixedValueTradeitemUom: function (sValue) {
            if (sValue || sValue === 0) {
                return getFixedValue("Uom", sValue);
            }
        },

        FixedValueTradeitemSertype: function (sValue) {
            if (sValue || sValue === 0) {
                return getFixedValue("Sertype", sValue);
            }
        },

        FixedValueTradeitemStatus: function (sValue) {
            if (sValue || sValue === 0) {
                return getFixedValue("Status", sValue);
            }
        }
    };
}, true);