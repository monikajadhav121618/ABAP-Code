/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define([
	"com/sap/cd/sttp/zcockpit/model/formatter/FixedValueFormatter"],
	function (FixedValueFormatter) {
		"use strict";

		return {
			TrnTypeToEpc: function (sValue) {
				if (sValue) {
					return "urn:epcglobal:cbv:btt:" + FixedValueFormatter.FixedValueBizTrnType(sValue).split(" - ")[0];
				} else {
					return sValue;
				}
			},

			EvttypeTechFormatter: function (sEvttype) {
				switch (sEvttype.trim()) {
					case '1':
						return "ObjectEvent";
					case '2':
						return "AggregationEvent";
					case '3':
						return "TransactionEvent";
					case '4':
						return "TransformationEvent";
					default:
						return undefined;
				}
			},

			MessageTypeFormatter: function (sValue) {
				switch (sValue) {
					case 'I':
						return "sap-icon://accept";
					case 'S':
						return "sap-icon://accept";
					case 'E':
						return "sap-icon://decline";
					case 'A':
						return "sap-icon://decline";
					case 'W':
						return "sap-icon://hint";
					default:
						return "sap-icon://question-mark";
				}
			}
		};
	}, true);