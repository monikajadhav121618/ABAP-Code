/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define([], function() {
	"use strict";

	/**
	 * Gets a fixed Value from the FixedValue Model
	 * 
	 * @param {string}
	 * 				sType the name of the fixed value set
	 * @param {string}
	 * 				sValue the given value for which the actual item from the FixedValue set should be returned
	 * @returns {string} the mapped value from the FixedValue set
	 * @public
	 */
	var getFixedValue = function(sType, sValue) {
		sValue = "" + sValue; //awkward but necessary string conversion
		var oFixedValueModel = sap.ui.getCore().getOwnerComponent().getModel("fixedValues");
		var aValues = oFixedValueModel.getProperty("/FixedValueSet/" + sType);
		if (aValues) {
			for (var i = 0; i < aValues.length; i++) {
				if (aValues[i].Valpos && aValues[i].Domvalue_l === sValue) {
					//return sValue + " - " + aValues[i].Ddtext;
					return aValues[i].Ddtext;
				}
			}
		}
		return sValue;
	};

	/**
	 * Collection of formatters which are accessing the FixedValues Model
	 * 
	 * @name com.sap.cd.sttp.zcockpit.model.formatter.FixedValueFormatter
	 */
	return {
		FixedValueObjType: function(sValue) {
			return getFixedValue("ObjType", sValue);
		},

		FixedValueStatusResponse: function(sValue) {
			return getFixedValue("StatusResponse", sValue);
		},

		FixedValueStatusObj: function(sValue) {
			if (sValue || sValue === 0) {
				return getFixedValue("StatusObj", sValue);
			}
		},

		FixedValueStatusPack: function(sValue) {
			if (sValue || sValue === 0) {
				return getFixedValue("StatusPack", sValue);
			}
		},

		FixedValueStatusHdr: function(sValue) {
			if (sValue || sValue === 0) {
				return getFixedValue("StatusHdr", sValue);
			}
		},

		FixedValueBizTrnType: function(sValue) {
			if (sValue || sValue === 0) {
				return getFixedValue("BizTrnType", sValue);
			}
		},

		FixedValueStatusStock: function(sValue) {
			if (sValue || sValue === 0) {
				return getFixedValue("StatusStock", sValue);
			}
		},

		FixedValueEvtaction: function(sValue) {
			if (sValue || sValue === 0) {
				return getFixedValue("Evtaction", sValue);
			}
		},

		FixedValueEvttype: function(sValue) {
			if (sValue || sValue === 0) {
				return getFixedValue("Evttype", sValue);
			}
		},

		FixedValueBizstep: function(sValue) {
			if (sValue || sValue === 0) {
				return getFixedValue("Bizstep", sValue);
			}
		},

		FixedValueDisposition: function(sValue) {
			if (sValue || sValue === 0) {
				if (sValue === "000" || sValue === 0) {
					return "";
				}
				return getFixedValue("Disposition", sValue);
			}
		},

		FixedValueDoctpe: function(sValue) {
			if (sValue || sValue === 0) {
				return getFixedValue("Doctpe", sValue);
			}
		},

		FixedValueStatusTrn: function(sValue) {
			if (sValue || sValue === 0) {
				return getFixedValue("StatusTrn", sValue);
			}
		},

		FixedValueStorage: function(sValue) {
			if (sValue || sValue === 0) {
				return getFixedValue("Storage", sValue);
			}
		},

		FixedValueAuthResultSum: function(sValue) {
			if (sValue || sValue === 0) {
				return getFixedValue("AuthResultSum", sValue);
			}
		},

		FixedValueStatusRepEvt: function(sValue) {
			if (sValue || sValue === 0) {
				return getFixedValue("StatusRepEvt", sValue);
			}
		},

		FixedValueLocType: function(sValue) {
			if (sValue || sValue === 0) {
				return getFixedValue("LocType", sValue);
			}
		},

		FixedValueSdCat: function(sValue) {
			if (sValue || sValue === 0) {
				return getFixedValue("SdCat", sValue);
			}
		}, 

		FixedValueSdType: function(sValue) {
			if (sValue || sValue === 0) {
				return getFixedValue("SdType", sValue);
			}
		}
	};
}, true);