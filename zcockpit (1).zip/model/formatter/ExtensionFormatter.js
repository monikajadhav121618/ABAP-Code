/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define([], function () {
    "use strict";

	/**
	 * Collection of different formatters that are required in conjunction with customer extensions.
	 * 
	 * @name com.sap.cd.sttp.zcockpit.model.formatter.ExtensionFormatter
	 */
    return {
        Column: function (aAttrib, sField) {
            if (aAttrib) {
                var oModel = sap.ui.getCore().getOwnerComponent().getModel();
                for (var i = 0, len = aAttrib.length; i < len; i++) {
                    var oProp = oModel.getProperty("/" + aAttrib[i]);
                    if (sField === oProp.field) {
                        return oProp.value;
                    }
                }
            }
        }
    };
}, true);