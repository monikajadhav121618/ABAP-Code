/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define([], function() {
	"use strict";

	/**
	 * Collection of different formatters
	 * 
	 * @name com.sap.cd.sttp.zcockpit.model.formatter.GeneralFormatter
	 */
	return {
		IndicatorIcon: function(sValue) {
			if (sValue === "X") {
				return "sap-icon://accept"
			} else {
				return null
			}
		},

		TranslateRoute: function(sRoute) {
			var sModel = sap.ui.getCore().getOwnerComponent().getModel("i18n");
			return sModel.getProperty(sRoute);
		},
		
		ToString: function(vValue) {
			if (vValue) {
				return vValue.toString();
			} else {
				return "";
			}
		},

		RemoveLeadingZeros: function(sValue) {
			var iValue = parseInt(sValue, 10);
			if (iValue) {
				return iValue.toString();
			} else {
				return sValue;
			}
		},

		DocPositionFormatter: function(sDocpos, sItemRef) {
			if (sItemRef && parseInt(sItemRef, 10) > 0) {
				return sItemRef + "-" + sDocpos;
			} else {
				return sDocpos;
			}
		},

		LocateObject: function(sId, sPath) {
			if (!sId || !sPath) {
				return false;
			}

			var aPath = sPath.split(",");

			if (aPath && $.inArray(sId, aPath) >= 0) {
				return true;
			}
			return false;
		},

		LengthToVisible: function(iValue) {
			return iValue > 0;
		},

		count: function(oValue) {
			if (oValue) {
				return oValue.length;
			}
		},

		statusButtonFormatter: function(sEvtType) {
			if (sEvtType === "OBSERVE") {
				return "sap-icon://show";
			}
			if (sEvtType === "ADD") {
				return "sap-icon://sys-add";
			}
			if (sEvtType === "DELETE") {
				return "sap-icon://sys-minus";
			}
			return "sap-icon://less";
		},

		statusButtonColorFormatter: function(sEvtType) {
			if (sEvtType === "OBSERVE") {
				return "blue";
			}
			if (sEvtType === "ADD") {
				return "green";
			}
			if (sEvtType === "DELETE") {
				return "red";
			}
			return "lightgray";
		},

		eventTypeIconFormatter: function(sEvtType) {
			if (sEvtType === 1) { // object
				return "sap-icon://notification";
			}
			if (sEvtType === 2) { // aggregation
				return "sap-icon://database";
			}
			if (sEvtType === 3) { // transaction
				return "sap-icon://form";
			}
			if (sEvtType === 4) { // transformation
				return "sap-icon://process";
			}
		},

		ItemCompState: function(iValue) {
			if (iValue !== 0) {
				return "Error";
			}
			return "Success";
		},

		DynamicAttrList: function(sType, sDynamicAttr, sDynamicAttrValue) {
			var oSettingsModel = sap.ui.getCore().getOwnerComponent().getModel("settings");
			var aList = oSettingsModel.getProperty("/" + sType + "/StaticAttr");
			
			if (!sType || (!sDynamicAttrValue && !sDynamicAttrValue === 0) || sDynamicAttrValue === "" ) {
				return false;
			}
			oSettingsModel.setProperty("/" + sType + "/HasDynamAttr", true);
			return true;
		},

		makeBool: function(oBoolValue) {
			if (oBoolValue || oBoolValue === "true") {
				return true;
			} else {
				return false;
			}
		}
	};
}, true);