/* 
* Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
*/ 
sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/model/resource/ResourceModel",
	"com/sap/cd/sttp/zcockpit/model/formatter/GeneralFormatter"
], function (JSONModel, Device, ODataModel, ResourceModel, GeneralFormatter) {
	"use strict";

	/**
	 * This module is responsible for creation of the different models which are involved in non-specific phases of the
	 * application. These models are generally created at the startup of the application.
	 *
	 * @name com.sap.cd.sttp.zcockpit.model.models
	 */
	return {

		/**
		 * Creates a JSONModel which serves as a global configuration for the application. These settings are required
		 * at different places in the application and can be easily extended. It contains constant properties aswell as
		 * the users timezone settings retrieved from the backend. The list of Static attributes serves for comparison
		 * in order to distinguish between fields that are added by the customer and standard fields.
		 *
		 * @param {object}
		 * 				oBaseModel the ODataModel reffering to the main backend service
		 * @returns {sap.ui.model.json.JSONModel} the Settings Model
		 * @public
		 */
		createSettingsModel: function (oBaseModel) {
			// settings model
			var oTB = new Date();
			oTB.setHours(0, 0, 0, 0);
			var oTE = new Date();
			oTE.setHours(24, 0, 0, 0);
			var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyyMMddHHmmss"
			});
			var oSettingsModel = new JSONModel({
				"LotnoFilter": "",
				"ShowBusy": false,
				"TodayBegin": oDateFormat.format(oTB),
				"TodayEnd": oDateFormat.format(oTE)
			});

			oSettingsModel.setDefaultBindingMode("OneWay");
			/*oBaseModel.read("/UserInfoSet", {
				"success": $.proxy(function (oData) {
					oSettingsModel.setProperty("/UTCDiff", oData.results[0].UTCDiff);
					oSettingsModel.setProperty("/UTCSign", oData.results[0].UTCSign);
				}, this)
			});*/
			return oSettingsModel;
		},

		/**
		 * Creates a JSONModel which registers to all occurences of the RouteMatched event of the Component Router.
		 * It tracks the history of all navigations taken inside the app and delivers a list in chronological order.
		 * This list is then used for the Global history feature accessible as a footer item in the application.
		 *
		 * @param {object}
		 * 				oRouter the instance of the Router which is initialised for the Component
		 * @returns {sap.ui.model.json.JSONModel} the Routing Model
		 * @public
		 */
		createRoutingModel: function (oRouter) {
			// routing model
			var routingModel = new JSONModel({
				arguments: {},
				log: []
			});
			oRouter.attachRouteMatched(
				function (oEvent) {
					var mParams = oEvent.getParameters();
					sap.ui.getCore().getOwnerComponent().getService("ShellUIService").then(
						function (oService) {
							oService.setTitle(GeneralFormatter.TranslateRoute(mParams.name));
						}
					);

					var aLog = routingModel.getProperty("/log");
					var sURL = oEvent.getSource().getURL(mParams.name, mParams.arguments);
					aLog.unshift({
						entry: sURL,
						name: mParams.name,
						arguments: mParams.arguments
					});
					routingModel.setProperty("/arguments", mParams.arguments);
					routingModel.setProperty("/log", aLog);
				});

			return routingModel;
		},

		createResourceModel: function (sBundleName) {
			var oResourceModel = new ResourceModel({
				"bundleName": sBundleName
			});
			return oResourceModel;
		},

		/**
		 * Creates a JSONModel which contains constants which describe the availability of fixed Values for certain
		 * sets of attribute values. Often attributes retrieved from the backend only consist of numeric status values
		 * which can then be mapped to short description texts. The 'FixedValueIds' array is a mapping from an app-
		 * internal representation and the technical name of the Text element in the backend. For each entry in this
		 * array the actual text is once retrieved from the backend in the users language. Afterwards different formatters
		 * can access these values and do the formatting on the UIs.
		 *
		 * @param {object}
		 * 				oBaseModel the ODataModel reffering to the main backend service
		 * @returns {sap.ui.model.json.JSONModel} the FixedValues Model
		 * @public
		 */
		createFixedValuesModel: function (oBaseModel) {
			// fetch fixed values and set new model
			var oFixedValueSetModel = new JSONModel({
				FixedValueSet: [],
				FixedValueIds: [{
					id: "StatusTrn",
					domain: "%2FSTTP%2FD_STAT_TRN"
				}, {
					id: "StatusHdr",
					domain: "%2FSTTP%2FD_STAT_TRN_HDR_ERP"
				}, {
					id: "BizTrnType",
					domain: "%2FSTTP%2FD_CTTYPENO"
				}, {
					id: "ObjType",
					domain: "%2FSTTP%2FD_OBJTYPE"
				}, {
					id: "Bizstep",
					domain: "%2FSTTP%2FD_CBIZSTEPNO"
				}, {
					id: "Disposition",
					domain: "%2FSTTP%2FD_CDISPOSNO"
				}, {
					id: "StatusObj",
					domain: "%2FSTTP%2FD_STAT_OBJ"
				}, {
					id: "StatusPack",
					domain: "%2FSTTP%2FD_STAT_PACK"
				}, {
					id: "StatusStock",
					domain: "%2FSTTP%2FD_STAT_STOCK"
				}, {
					id: "Evttype",
					domain: "%2FSTTP%2FD_EVTTYPE"
				}, {
					id: "Evtaction",
					domain: "%2FSTTP%2FD_EVTACTION"
				}, {
					id: "Storage",
					domain: "%2FSTTP%2FD_STORAGE"
				}, {
					id: "XFeld",
					domain: "XFELD"
				}, {
					id: "StatusEvt",
					domain: "%2FSTTP%2FD_STAT_EVT"
				}, {
					id: "Doctpe",
					domain: "%2FSTTP%2FD_DOCTPE"
				}, {
					id: "AuthResultSum",
					domain: "%2FSTTP%2FD_AUTH_RESULT_SUM"
				}, {
					id: "StatusRepEvt",
					domain: "%2FSTTP%2FD_STATUS_REP_EVT"
				}, {
					id: "StatusResponse",
					domain: "%2FSTTP%2FD_REP_STATUS_RESP"
				}, {
					id: "LocType",
					domain: "%2FSTTP%2FD_LOCTYPE"
				}, {
					id: "SdCat",
					domain: "%2FSTTP%2FD_SD_CATEGORY"
				}, {
					id: "SdType",
					domain: "%2FSTTP%2FD_SD_TYPE"
				}]
			});
			oFixedValueSetModel.setDefaultBindingMode("OneWay");
			var aFixedValueIds = oFixedValueSetModel.getProperty("/FixedValueIds");

			var fnSuccess = function (oData) {
				var aResponse = oData.FixedTypeValues.results;
				// inserting dummy value at position #0 for dropdown controls
				aResponse.unshift({
					Valpos: "",
					Domvalue_l: "",
					Ddtext: ""
				});
				for (var i = 0; i < aFixedValueIds.length; i++) {
					var oFixedValue = aFixedValueIds[i];
					if (oFixedValue.domain.replace("%2FSTTP%2F", "") === oData.type.replace("/STTP/", "")) {
						oFixedValueSetModel.setProperty("/FixedValueSet/" + oFixedValue.id, aResponse);
					}
				}
				oBaseModel.updateBindings(true);
			};

			for (var ii = 0; ii < aFixedValueIds.length; ii++) {
				oBaseModel.read("/FixedValueTypeSet('" + aFixedValueIds[ii].domain + "')", {
					"success": fnSuccess,
					"urlParameters": {
						"$expand": "FixedTypeValues"
					}
				});
			}
			return oFixedValueSetModel;
		},

		/**
		 * Creates a JSONModel which contains constants which describe the availability of fixed Values for certain
		 * sets of attribute values. Often attributes retrieved from the backend only consist of numeric status values
		 * which can then be mapped to short description texts. The 'FixedValueIds' array is a mapping from an app-
		 * internal representation and the technical name of the Text element in the backend. For each entry in this
		 * array the actual text is once retrieved from the backend in the users language. Afterwards different formatters
		 * can access these values and do the formatting on the UIs.
		 *
		 * @param {object}
		 * 				oBaseModel the ODataModel reffering to the md backend service
		 * @returns {sap.ui.model.json.JSONModel} the FixedValues Model
		 * @public
		 */
		createFixedValuesModel_MD: function (oBaseModel) {
			// fetch fixed values and set new model
			var oFixedValueSetModel = new JSONModel({
				FixedValueSet: [],
				FixedValueIds: [{
					id: "Sertype",
					domain: "%2FSTTP%2FD_SERTYPE"
				}, {
					id: "UoM",
					domain: "%2FSTTP%2FD_UOM"
				}, {
					id: "Status",
					domain: "%2FSTTP%2FD_STATUS_PROD"
				}]
			});
			oFixedValueSetModel.setDefaultBindingMode("OneWay");
			var aFixedValueIds = oFixedValueSetModel.getProperty("/FixedValueIds");

			var fnSuccess = function (oData) {
				var aResponse = oData.FixedTypeValues.results;
				// inserting dummy value at position #0 for dropdown controls
				aResponse.unshift({
					Valpos: "",
					Domvalue_l: "",
					Ddtext: ""
				});
				for (var i = 0; i < aFixedValueIds.length; i++) {
					var oFixedValue = aFixedValueIds[i];
					if (oFixedValue.domain.replace("%2FSTTP%2F", "") === oData.type.replace("/STTP/", "")) {
						oFixedValueSetModel.setProperty("/FixedValueSet/" + oFixedValue.id, aResponse);
					}
				}
				oBaseModel.updateBindings(true);
			};

			for (var ii = 0; ii < aFixedValueIds.length; ii++) {
				oBaseModel.read("/FixedValueTypeSet('" + aFixedValueIds[ii].domain + "')", {
					"success": fnSuccess,
					"urlParameters": {
						"$expand": "FixedTypeValues"
					}
				});
			}
			return oFixedValueSetModel;
		},

		createExtensionModel: function () {
			var oExtModel = new sap.ui.model.json.JSONModel();
			// Overwrite getProperty
			oExtModel.getProperty = function (s) {
				return s;
			};
			return oExtModel;
		}
	};
});